// Initialize MongoDB databases and collections for all services
// This script runs automatically when MongoDB container starts

// Create order_system database and collections
db = db.getSiblingDB('order_system');

// Create collections with validation schema
db.orders.insertOne({ _id: "init", timestamp: new Date() });
db.orders.deleteOne({ _id: "init" });
db.orders.createIndex({ 'order_id': 1 }, { unique: true });
db.orders.createIndex({ 'timestamp': 1 });

// Create DLQ collection for failed orders
db.dlq_orders.insertOne({ _id: "init", timestamp: new Date() });
db.dlq_orders.deleteOne({ _id: "init" });
db.dlq_orders.createIndex({ 'timestamp': 1 });

// Create idempotency collection
db.idempotency_keys.insertOne({ _id: "init", timestamp: new Date() });
db.idempotency_keys.deleteOne({ _id: "init" });
db.idempotency_keys.createIndex({ 'key': 1 }, { unique: true });
db.idempotency_keys.createIndex({ 'timestamp': 1 }, { expireAfterSeconds: 86400 });

console.log('✓ MongoDB initialized successfully');
console.log('✓ Database created: order_system');
console.log('✓ Collections created: orders, dlq_orders, idempotency_keys');
