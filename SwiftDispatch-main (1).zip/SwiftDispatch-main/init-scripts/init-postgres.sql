-- Initialize PostgreSQL databases for all services
-- This script runs automatically when PostgreSQL container starts

-- Create databases
CREATE DATABASE dcc_userdb OWNER postgres;
CREATE DATABASE payment_db OWNER postgres;
CREATE DATABASE payment_consumer_db OWNER postgres;

-- Grant privileges
GRANT ALL PRIVILEGES ON DATABASE dcc_userdb TO postgres;
GRANT ALL PRIVILEGES ON DATABASE payment_db TO postgres;
GRANT ALL PRIVILEGES ON DATABASE payment_consumer_db TO postgres;

-- Connect to each database and set up initial schema (will be created by ORM)
\c dcc_userdb;
-- User database schema will be created by Alembic on startup

\c payment_db;
-- Payment database schema will be created by SQLAlchemy on startup

\c payment_consumer_db;
-- Payment consumer database schema will be created by SQLAlchemy on startup
