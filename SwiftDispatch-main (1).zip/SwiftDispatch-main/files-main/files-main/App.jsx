import { useState } from 'react'
import AuthForms   from './components/AuthForms'
import UserList    from './components/UserList'
import GetUserById from './components/GetUserById'
import APIConfig   from './components/APIConfig'

const TABS = [
  { id: 'auth',    label: 'Auth' },
  { id: 'users',   label: 'All Users' },
  { id: 'find',    label: 'Find by ID' },
  { id: 'config',  label: 'Config' },
]

export default function App() {
  const [tab, setTab]         = useState('auth')
  const [authData, setAuthData] = useState(null)

  const handleLoginSuccess = (data) => {
    setAuthData(data)
    // Auto-switch to user list after login
    setTimeout(() => setTab('users'), 800)
  }

  return (
    <div className="app-shell">
      <header className="header">
        <div className="header-logo">user<span>_module</span></div>
        <nav className="nav">
          {TABS.map(t => (
            <button
              key={t.id}
              className={`nav-btn ${tab === t.id ? 'active' : ''}`}
              onClick={() => setTab(t.id)}
            >
              {t.label}
            </button>
          ))}
        </nav>
        {authData && (
          <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <span style={{ color: 'var(--muted)', fontSize: '0.8rem' }}>
              Logged in as <strong style={{ color: 'var(--accent)' }}>{authData.user?.name || authData.user?.email || 'user'}</strong>
            </span>
            <button className="btn btn-ghost btn-sm" onClick={() => {
              localStorage.removeItem('token')
              setAuthData(null)
              setTab('auth')
            }}>Logout</button>
          </div>
        )}
      </header>

      <main className="main-content">
        {tab === 'auth'   && <AuthForms onLoginSuccess={handleLoginSuccess} />}
        {tab === 'users'  && <UserList />}
        {tab === 'find'   && <GetUserById />}
        {tab === 'config' && <APIConfig />}
      </main>
    </div>
  )
}
