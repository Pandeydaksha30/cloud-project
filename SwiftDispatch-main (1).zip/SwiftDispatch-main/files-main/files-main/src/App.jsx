import React, { useState } from 'react'
import axios from 'axios'

export default function App() {
  const [files, setFiles] = useState([])
  const [uploading, setUploading] = useState(false)
  const [error, setError] = useState(null)

  const handleFileSelect = async (e) => {
    const selectedFiles = e.target.files
    if (!selectedFiles || selectedFiles.length === 0) return

    setUploading(true)
    setError(null)

    try {
      for (let file of selectedFiles) {
        const formData = new FormData()
        formData.append('file', file)

        // Upload to backend (adjust endpoint as needed)
        const response = await axios.post(
          'http://localhost:8000/api/upload',
          formData,
          {
            headers: { 'Content-Type': 'multipart/form-data' }
          }
        )

        setFiles(prev => [...prev, {
          name: file.name,
          size: file.size,
          uploadedAt: new Date().toLocaleString(),
          id: response.data.id || file.name
        }])
      }
    } catch (err) {
      setError(err.message || 'Upload failed')
    } finally {
      setUploading(false)
    }
  }

  return (
    <div style={{ padding: '2rem', maxWidth: '800px', margin: '0 auto' }}>
      <h1 style={{ marginBottom: '1rem' }}>📁 File Upload Module</h1>

      <div style={{
        border: '2px dashed #667eea',
        borderRadius: '8px',
        padding: '2rem',
        textAlign: 'center',
        marginBottom: '2rem',
        cursor: 'pointer',
        backgroundColor: '#f5f7ff'
      }}>
        <label htmlFor="file-input" style={{ cursor: 'pointer' }}>
          <div style={{ fontSize: '2rem', marginBottom: '1rem' }}>📤</div>
          <div style={{ fontSize: '1.1rem', marginBottom: '0.5rem' }}>
            Click to upload or drag files here
          </div>
          <div style={{ fontSize: '0.9rem', color: '#666' }}>
            PNG, JPG, PDF, DOC and more (max 100MB)
          </div>
        </label>
        <input
          id="file-input"
          type="file"
          multiple
          onChange={handleFileSelect}
          disabled={uploading}
          style={{ display: 'none' }}
        />
      </div>

      {error && (
        <div style={{
          padding: '1rem',
          backgroundColor: '#fee',
          color: '#c33',
          borderRadius: '4px',
          marginBottom: '1rem'
        }}>
          ❌ {error}
        </div>
      )}

      {uploading && (
        <div style={{
          padding: '1rem',
          backgroundColor: '#eef',
          color: '#337',
          borderRadius: '4px',
          marginBottom: '1rem'
        }}>
          ⏳ Uploading...
        </div>
      )}

      {files.length > 0 && (
        <div>
          <h2 style={{ marginBottom: '1rem' }}>Uploaded Files ({files.length})</h2>
          <div style={{
            display: 'grid',
            gap: '1rem'
          }}>
            {files.map(file => (
              <div
                key={file.id}
                style={{
                  padding: '1rem',
                  backgroundColor: '#f9f9f9',
                  border: '1px solid #ddd',
                  borderRadius: '4px',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center'
                }}
              >
                <div>
                  <div style={{ fontWeight: 'bold', marginBottom: '0.25rem' }}>
                    📄 {file.name}
                  </div>
                  <div style={{ fontSize: '0.9rem', color: '#666' }}>
                    Size: {(file.size / 1024).toFixed(2)} KB | Uploaded: {file.uploadedAt}
                  </div>
                </div>
                <button
                  onClick={() => setFiles(files.filter(f => f.id !== file.id))}
                  style={{
                    padding: '0.5rem 1rem',
                    backgroundColor: '#f44',
                    color: 'white',
                    border: 'none',
                    borderRadius: '4px',
                    cursor: 'pointer'
                  }}
                >
                  Delete
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {files.length === 0 && !uploading && (
        <div style={{
          textAlign: 'center',
          color: '#999',
          padding: '2rem'
        }}>
          No files uploaded yet
        </div>
      )}
    </div>
  )
}
