// ── backend-cors-patch.js ──────────────────────────────────
// Add this CORS middleware to your Express backend.
// 
// STEP 1: Install cors
//   npm install cors
//
// STEP 2: In your main file (app.js / server.js / index.js),
//         add the following lines BEFORE your routes:

const cors = require('cors')

app.use(cors({
  origin: ['http://localhost:5173', 'http://localhost:3000'],
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true,
}))

// ── OR for open dev CORS (any origin) ──────────────────────
// app.use(cors())

// ── Example full server.js / app.js with CORS ──────────────
/*
const express = require('express')
const cors    = require('cors')
const app     = express()

app.use(cors({
  origin: 'http://localhost:5173',
  methods: ['GET','POST','PUT','DELETE'],
  allowedHeaders: ['Content-Type','Authorization'],
}))

app.use(express.json())

// ... your routes here
*/
