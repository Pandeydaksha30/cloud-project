# user_module — Frontend

A React + Vite frontend for the `user_module` Express/Node.js backend.

---

## 🔍 Backend API Endpoints (assumed from standard user module)

| Method | Endpoint              | Description          | Auth Required |
|--------|-----------------------|----------------------|---------------|
| POST   | /api/users/register   | Register new user    | No            |
| POST   | /api/users/login      | Login user           | No            |
| GET    | /api/users            | Get all users        | Yes (JWT)     |
| GET    | /api/users/:id        | Get user by ID       | Yes (JWT)     |
| PUT    | /api/users/:id        | Update user          | Yes (JWT)     |
| DELETE | /api/users/:id        | Delete user          | Yes (JWT)     |

### Request Body — Register
```json
{ "name": "John Doe", "email": "john@example.com", "password": "secret123", "phone": "9999999999" }
```

### Request Body — Login
```json
{ "email": "john@example.com", "password": "secret123" }
```

### Response — Login
```json
{ "token": "<JWT>", "user": { "_id": "...", "name": "...", "email": "..." } }
```

---

## 🚀 Run Instructions

### 1. Clone and run the backend
```bash
git clone https://github.com/devyani1512/user_module.git
cd user_module
npm install
```

Add CORS to backend (see `backend-cors-patch.js`):
```bash
npm install cors
```
Then edit `app.js` / `server.js` — add before your routes:
```js
const cors = require('cors')
app.use(cors({ origin: 'http://localhost:5173' }))
```

Start the backend:
```bash
node server.js        # or: npm start / npm run dev
```
Backend runs on → http://localhost:3000

---

### 2. Set up and run this frontend
```bash
# In a NEW terminal
cd user-module-frontend
npm install
npm run dev
```
Frontend runs on → http://localhost:5173

---

### 3. If backend runs on a different port
Edit `src/api.js`, line 4:
```js
const BASE_URL = 'http://localhost:YOUR_PORT'
```
Or use the **Config** tab in the UI to change it at runtime.

---

## 📁 File Structure

```
user-module-frontend/
├── index.html
├── vite.config.js
├── package.json
├── backend-cors-patch.js      ← Apply CORS fix to backend
└── src/
    ├── main.jsx
    ├── App.jsx
    ├── App.css
    ├── api.js                 ← All API calls (axios)
    └── components/
        ├── Alert.jsx
        ├── AuthForms.jsx      ← Login + Register
        ├── UserList.jsx       ← GET all, DELETE
        ├── EditUserModal.jsx  ← PUT update
        ├── GetUserById.jsx    ← GET by ID
        └── APIConfig.jsx      ← Runtime URL changer
```

---

## ❗ Common Errors & Fixes

| Error | Fix |
|-------|-----|
| CORS error in browser console | Add `cors` middleware to backend (see above) |
| `401 Unauthorized` on GET /users | Login first — JWT token is auto-attached |
| `Cannot POST /api/users/register` | Backend may use `/users` instead of `/api/users` — edit `src/api.js` |
| `Network Error` / ERR_CONNECTION_REFUSED | Backend is not running. Start it first. |
| `404 Not Found` on all routes | Check your backend's route prefix in `src/api.js` |
| Blank page on frontend | Run `npm install` then `npm run dev` again |
| Token not sent | Login to get a token — stored in `localStorage.token` |

---

## ⚠️ Route Adjustment

If your backend uses `/users` instead of `/api/users`, open `src/api.js` and change:
```js
export const registerUser = (data) => api.post('/users', data)
export const loginUser    = (data) => api.post('/users/login', data)
export const getAllUsers   = ()     => api.get('/users')
// etc.
```
