import axios from 'axios'

// ── Change this if your backend runs on a different port ──
const BASE_URL = 'http://localhost:3000'

const api = axios.create({
  baseURL: BASE_URL,
  headers: { 'Content-Type': 'application/json' },
})

// Attach token if present (for JWT-protected backends)
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

// ── User CRUD ──────────────────────────────────────────────
export const registerUser   = (data) => api.post('/api/users/register', data)
export const loginUser      = (data) => api.post('/api/users/login', data)
export const getAllUsers     = ()     => api.get('/api/users')
export const getUserById     = (id)   => api.get(`/api/users/${id}`)
export const updateUser      = (id, data) => api.put(`/api/users/${id}`, data)
export const deleteUser      = (id)   => api.delete(`/api/users/${id}`)

// Alternative route shapes some backends use
export const getAllUsersAlt  = ()     => api.get('/users')
export const getUserByIdAlt  = (id)   => api.get(`/users/${id}`)
export const registerUserAlt = (data) => api.post('/users', data)
export const updateUserAlt   = (id, data) => api.put(`/users/${id}`, data)
export const deleteUserAlt   = (id)   => api.delete(`/users/${id}`)

export default api
