#!/bin/bash

# ============================================
# PROJECT INTEGRATION - MAIN LAUNCHER
# One-command executable for entire project
# ============================================

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Banner
echo -e "${BLUE}"
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║                                                                ║"
echo "║          🚀 PROJECT INTEGRATION - LAUNCHER 🚀                 ║"
echo "║                                                                ║"
echo "║              Food Delivery Microservices Platform             ║"
echo "║                                                                ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo -e "${RED}✗ Docker is not installed. Please install Docker first.${NC}"
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo -e "${RED}✗ Docker Compose is not installed. Please install Docker Compose first.${NC}"
    exit 1
fi

echo -e "${YELLOW}📋 Pre-flight checks...${NC}"

# Check for required files
if [ ! -f "docker-compose.yml" ]; then
    echo -e "${RED}✗ docker-compose.yml not found${NC}"
    exit 1
fi

if [ ! -f ".env" ]; then
    echo -e "${YELLOW}⚠ .env file not found. Creating from .env.example...${NC}"
    cp .env.example .env
fi

echo -e "${GREEN}✓ All checks passed${NC}"
echo ""

# Parse command line arguments
COMMAND=${1:-up}
BUILD_FLAG=${2:-}

case $COMMAND in
    up)
        echo -e "${BLUE}📦 Starting all services...${NC}"
        if [ "$BUILD_FLAG" = "--build" ]; then
            echo -e "${YELLOW}🔨 Building images...${NC}"
            docker-compose build
        fi
        
        echo -e "${YELLOW}⏱️ Starting containers...${NC}"
        docker-compose up -d
        
        echo ""
        echo -e "${GREEN}✓ All services started!${NC}"
        echo ""
        echo -e "${BLUE}📊 SERVICE ENDPOINTS:${NC}"
        echo ""
        echo "  🔷 User Module:              http://localhost:8001"
        echo "  🔷 CloudPBL Backend:         http://localhost:8002"
        echo "  🔷 Payment Module:           http://localhost:8003"
        echo "  🔷 Restaurant Service:       http://localhost:8004"
        echo "  🔷 Payment Success Consumer: http://localhost:8005"
        echo ""
        echo "  🔵 CloudPBL Frontend:        http://localhost:5173"
        echo "  🔵 Files Module:             http://localhost:5174"
        echo ""
        echo "  🗄️  PostgreSQL:              localhost:5432 (postgres:postgres)"
        echo "  🗄️  MongoDB:                 localhost:27017 (admin:admin)"
        echo "  🗄️  Redis:                   localhost:6379"
        echo ""
        echo -e "${YELLOW}💡 View logs: docker-compose logs -f [service_name]${NC}"
        echo -e "${YELLOW}💡 Scale worker: docker-compose up -d --scale celery-worker=3${NC}"
        ;;
    
    down)
        echo -e "${BLUE}🛑 Stopping all services...${NC}"
        docker-compose down
        echo -e "${GREEN}✓ Services stopped${NC}"
        ;;
    
    restart)
        echo -e "${BLUE}🔄 Restarting all services...${NC}"
        docker-compose restart
        echo -e "${GREEN}✓ Services restarted${NC}"
        ;;
    
    logs)
        SERVICE=${2:-}
        if [ -z "$SERVICE" ]; then
            echo -e "${BLUE}📋 Showing logs for all services...${NC}"
            docker-compose logs -f
        else
            echo -e "${BLUE}📋 Showing logs for $SERVICE...${NC}"
            docker-compose logs -f "$SERVICE"
        fi
        ;;
    
    build)
        echo -e "${BLUE}🔨 Building all services...${NC}"
        docker-compose build
        echo -e "${GREEN}✓ Build complete${NC}"
        ;;
    
    clean)
        echo -e "${YELLOW}🗑️  Cleaning up containers and volumes...${NC}"
        read -p "⚠️  This will delete all data. Continue? (y/N): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            docker-compose down -v
            echo -e "${GREEN}✓ Cleanup complete${NC}"
        else
            echo -e "${YELLOW}Cancelled${NC}"
        fi
        ;;
    
    ps)
        echo -e "${BLUE}📊 Running containers:${NC}"
        docker-compose ps
        ;;
    
    test)
        echo -e "${BLUE}🧪 Running health checks...${NC}"
        
        echo ""
        echo "Testing endpoints..."
        
        # Test all services
        services=(
            "http://localhost:8001/health User Module"
            "http://localhost:8002/health CloudPBL Backend"
            "http://localhost:8003/health Payment Module"
            "http://localhost:8004/health Restaurant Service"
            "http://localhost:8005/health Payment Consumer"
        )
        
        for service in "${services[@]}"; do
            url=$(echo $service | cut -d' ' -f1)
            name=$(echo $service | cut -d' ' -f2-)
            
            if curl -s -f "$url" > /dev/null 2>&1; then
                echo -e "  ${GREEN}✓${NC} $name"
            else
                echo -e "  ${RED}✗${NC} $name"
            fi
        done
        
        echo ""
        echo "Testing databases..."
        
        # Test PostgreSQL
        if docker-compose exec -T postgres pg_isready -U postgres > /dev/null 2>&1; then
            echo -e "  ${GREEN}✓${NC} PostgreSQL"
        else
            echo -e "  ${RED}✗${NC} PostgreSQL"
        fi
        
        # Test MongoDB
        if docker-compose exec -T mongodb mongosh --eval "db.adminCommand('ping')" > /dev/null 2>&1; then
            echo -e "  ${GREEN}✓${NC} MongoDB"
        else
            echo -e "  ${RED}✗${NC} MongoDB"
        fi
        
        # Test Redis
        if docker-compose exec -T redis redis-cli ping > /dev/null 2>&1; then
            echo -e "  ${GREEN}✓${NC} Redis"
        else
            echo -e "  ${RED}✗${NC} Redis"
        fi
        
        echo ""
        echo -e "${GREEN}✓ Health check complete${NC}"
        ;;
    
    help|--help|-h)
        echo -e "${BLUE}📚 USAGE:${NC}"
        echo ""
        echo "  ./launcher.sh [command] [options]"
        echo ""
        echo -e "${BLUE}COMMANDS:${NC}"
        echo ""
        echo "  up [--build]      Start all services (optionally rebuild)"
        echo "  down              Stop all services"
        echo "  restart           Restart all services"
        echo "  logs [service]    View logs (all or specific service)"
        echo "  build             Build all images"
        echo "  ps                List running containers"
        echo "  test              Run health checks on all services"
        echo "  clean             Remove containers and volumes (⚠️ data loss)"
        echo "  help              Show this help message"
        echo ""
        echo -e "${BLUE}EXAMPLES:${NC}"
        echo ""
        echo "  ./launcher.sh up                 # Start all services"
        echo "  ./launcher.sh up --build         # Rebuild and start"
        echo "  ./launcher.sh logs user-module   # View user-module logs"
        echo "  ./launcher.sh test               # Run health checks"
        echo "  ./launcher.sh down               # Stop all services"
        echo ""
        ;;
    
    *)
        echo -e "${RED}✗ Unknown command: $COMMAND${NC}"
        echo -e "${YELLOW}Try './launcher.sh help' for usage information${NC}"
        exit 1
        ;;
esac
