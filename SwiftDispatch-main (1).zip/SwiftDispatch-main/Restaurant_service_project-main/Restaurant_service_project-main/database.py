import json
import os
import sqlite3
from threading import Lock

_DB_PATH = os.getenv("DATABASE_URL", "./restaurant.db")
_lock = Lock()


def _conn():
    c = sqlite3.connect(_DB_PATH, check_same_thread=False)
    c.row_factory = sqlite3.Row
    return c


def _init():
    with _conn() as c:
        c.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                idempotency_key TEXT UNIQUE NOT NULL,
                data            TEXT NOT NULL
            )
        """)
        c.execute("""
            CREATE TABLE IF NOT EXISTS dead_letter_queue (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                data       TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        c.commit()


_init()


def save_order(order: dict):
    key = order.get("idempotency_key", "")
    with _lock, _conn() as c:
        c.execute(
            "INSERT OR IGNORE INTO orders (idempotency_key, data) VALUES (?, ?)",
            (key, json.dumps(order)),
        )
        c.commit()


def load_keys() -> list[str]:
    with _conn() as c:
        return [r["idempotency_key"] for r in c.execute("SELECT idempotency_key FROM orders")]


def save_dlq(order: dict):
    with _lock, _conn() as c:
        c.execute("INSERT INTO dead_letter_queue (data) VALUES (?)", (json.dumps(order),))
        c.commit()


def get_dlq() -> list[dict]:
    with _conn() as c:
        return [json.loads(r["data"]) for r in c.execute("SELECT data FROM dead_letter_queue ORDER BY id")]
