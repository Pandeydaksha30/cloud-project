from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException
import threading

from database import save_order, load_keys, get_dlq
from cache import exists, save, cache
from sqs_simulator import send_message
from worker import start_worker


@asynccontextmanager
async def lifespan(app: FastAPI):
    keys = load_keys()
    for k in keys:
        cache.add(k)
    print("Cache rebuilt")
    threading.Thread(target=start_worker, daemon=True).start()
    yield


app = FastAPI(lifespan=lifespan)


@app.get("/health")
def health_check():
    """Health check endpoint for Docker container monitoring."""
    return {"status": "healthy", "service": "restaurant-service"}


@app.get("/dlq")
def view_dlq():
    return {"failed_messages": get_dlq()}


@app.post("/payment/webhook")

def webhook(order: dict):

    key = order["idempotency_key"]

    if exists(key):

        raise HTTPException(409, "Duplicate request")

    save_order(order)

    save(key)

    send_message(order)

    return {"status": "Order Accepted"}