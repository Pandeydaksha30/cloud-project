import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App.jsx'
import AppClaude from './AppClaude.jsx'

const useClaudeDemo = window.location.hash === '#claude'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    {useClaudeDemo ? <AppClaude /> : <App />}
  </StrictMode>,
)
