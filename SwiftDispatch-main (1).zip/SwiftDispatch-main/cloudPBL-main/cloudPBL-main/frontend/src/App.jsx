import React, { useState, useEffect, useRef, useCallback } from 'react';
import axios from 'axios';

const API_USER     = import.meta.env.VITE_USER_URL     || 'http://localhost:8001';
const API_PAYMENT  = import.meta.env.VITE_PAYMENT_URL  || 'http://localhost:8003';
const API_DISPATCH = import.meta.env.VITE_DISPATCH_URL || 'http://localhost:8002';

const userAPI     = axios.create({ baseURL: API_USER,     timeout: 10000 });
const paymentAPI  = axios.create({ baseURL: API_PAYMENT,  timeout: 10000 });
const dispatchAPI = axios.create({ baseURL: API_DISPATCH, timeout: 10000 });

[userAPI, paymentAPI, dispatchAPI].forEach(api =>
  api.interceptors.request.use(cfg => {
    const t = localStorage.getItem('auth_token');
    if (t) cfg.headers.Authorization = `Bearer ${t}`;
    return cfg;
  })
);

// ── Design tokens ─────────────────────────────────────────────────────────────
const CSS = `
  *{box-sizing:border-box;margin:0;padding:0}
  :root{
    --bg:#0a0a0f;--bg2:#12121a;--bg3:#1a1a26;--surface:#1e1e2e;
    --border:rgba(255,255,255,0.08);--text:#e8e8f0;--text2:#8888aa;
    --brand:#ff4d6d;--brand2:#ff6b35;--green:#2dd4a0;--red:#f87171;--yellow:#fbbf24;--blue:#60a5fa;
  }
  html,body,#root{height:100%;width:100%}
  body{background:var(--bg);color:var(--text);font-family:'Segoe UI',sans-serif;font-size:13px}
  .app{display:flex;flex-direction:column;height:100vh}

  /* header */
  .header{padding:10px 20px;border-bottom:1px solid var(--border);background:var(--bg2);
    display:flex;align-items:center;gap:16px;flex-shrink:0}
  .logo{font-size:17px;font-weight:800;color:var(--brand);white-space:nowrap;letter-spacing:-.3px}
  .tabs{display:flex;gap:6px;flex:1}
  .tab{padding:5px 13px;border:1px solid var(--border);background:transparent;
    color:var(--text2);cursor:pointer;border-radius:4px;font-size:12px;font-weight:600}
  .tab.active{background:var(--brand);color:#fff;border-color:var(--brand)}
  .user-info{margin-left:auto;display:flex;align-items:center;gap:10px;font-size:12px;color:var(--text2)}
  .logout-btn{padding:4px 9px;background:transparent;border:1px solid var(--border);
    cursor:pointer;border-radius:4px;font-size:11px;color:var(--text2)}

  .content{flex:1;overflow-y:auto;padding:16px}

  /* cards */
  .card{background:var(--bg3);border-radius:10px;border:1px solid var(--border);padding:20px;margin-bottom:16px}
  .card-title{font-size:14px;font-weight:700;color:var(--brand);margin-bottom:14px}

  /* forms */
  .form-group{margin-bottom:12px}
  label{display:block;font-size:10px;font-weight:700;margin-bottom:4px;
    color:var(--text2);text-transform:uppercase;letter-spacing:.6px}
  input,select{width:100%;padding:8px 12px;border:1px solid var(--border);
    background:var(--surface);color:var(--text);border-radius:5px;font-size:12px}
  input:focus,select:focus{outline:none;border-color:var(--brand)}

  /* buttons */
  .btn{padding:9px 18px;background:var(--brand);color:#fff;border:none;border-radius:5px;
    cursor:pointer;font-size:12px;font-weight:700;transition:opacity .15s;display:inline-flex;align-items:center;gap:6px}
  .btn:hover{opacity:.85}
  .btn:disabled{opacity:.35;cursor:not-allowed}
  .btn-ghost{background:transparent;border:1px solid var(--border);color:var(--text2)}
  .btn-green{background:#16a34a}
  .btn-blue{background:#2563eb}
  .btn-sm{padding:5px 10px;font-size:11px}

  /* messages */
  .msg{padding:9px 13px;border-radius:5px;font-size:12px;margin-bottom:12px;line-height:1.5}
  .msg.ok{background:rgba(45,212,160,.12);color:var(--green);border:1px solid rgba(45,212,160,.25)}
  .msg.err{background:rgba(248,113,113,.12);color:var(--red);border:1px solid rgba(248,113,113,.25)}
  .msg.info{background:rgba(96,165,250,.1);color:var(--blue);border:1px solid rgba(96,165,250,.2)}

  /* auth */
  .login-screen{display:flex;align-items:center;justify-content:center;height:100vh}
  .login-card{background:var(--bg3);border:1px solid var(--border);padding:36px;border-radius:14px;width:400px}
  .login-title{font-size:22px;font-weight:800;margin-bottom:4px;color:var(--brand)}
  .login-sub{color:var(--text2);font-size:12px;margin-bottom:24px}

  /* step indicator */
  .steps{display:flex;align-items:center;gap:4px;margin-bottom:20px;flex-wrap:wrap}
  .step-pill{padding:4px 12px;border-radius:20px;font-size:11px;font-weight:700;
    border:1px solid var(--border);color:var(--text2);transition:all .2s}
  .step-pill.active{background:var(--brand);color:#fff;border-color:transparent}
  .step-pill.done{background:rgba(45,212,160,.15);color:var(--green);border-color:rgba(45,212,160,.3)}
  .step-arrow{color:var(--border);font-size:14px}

  /* restaurant grid */
  .rest-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:10px;margin-bottom:16px}
  .rest-card{background:var(--surface);border:2px solid var(--border);border-radius:8px;
    padding:14px;cursor:pointer;transition:border-color .15s,transform .1s}
  .rest-card:hover{transform:translateY(-1px)}
  .rest-card.sel{border-color:var(--brand)}
  .rest-emoji{font-size:30px;margin-bottom:6px}
  .rest-name{font-weight:700;font-size:13px}
  .rest-price{color:var(--brand);font-size:13px;font-weight:700;margin-top:3px}
  .rest-items{color:var(--text2);font-size:11px;margin-top:3px}

  /* payment review */
  .pay-box{background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:16px;margin-bottom:16px}
  .pay-row{display:flex;justify-content:space-between;align-items:center;padding:6px 0;
    border-bottom:1px solid var(--border);font-size:12px}
  .pay-row:last-child{border-bottom:none;font-weight:700;font-size:13px;padding-top:10px}
  .pay-badge{display:inline-block;padding:2px 8px;border-radius:10px;font-size:10px;font-weight:700;
    background:rgba(251,191,36,.15);color:var(--yellow);border:1px solid rgba(251,191,36,.25)}

  /* event log */
  .event-log{background:var(--bg2);border:1px solid var(--border);border-radius:6px;
    padding:12px;max-height:300px;overflow-y:auto;font-family:monospace;font-size:11px;line-height:1.7}
  .ev{padding:1px 0}
  .ev-badge{display:inline-block;padding:1px 6px;border-radius:8px;font-size:10px;
    font-weight:700;margin-right:5px;text-transform:uppercase}
  .ev-ok{background:rgba(45,212,160,.2);color:var(--green)}
  .ev-err{background:rgba(248,113,113,.2);color:var(--red)}
  .ev-info{background:rgba(96,165,250,.15);color:var(--blue)}

  /* rider list */
  .rider-row{background:var(--surface);border-radius:6px;padding:10px 14px;margin-bottom:6px;
    display:flex;align-items:center;gap:12px}
  .dot{width:9px;height:9px;border-radius:50%;flex-shrink:0}

  /* order history */
  .hist-row{background:var(--surface);border-radius:6px;padding:11px 16px;margin-bottom:7px;
    display:flex;align-items:center;gap:12px}

  /* grid helpers */
  .two-col{display:grid;grid-template-columns:1fr 1fr;gap:16px}
  @media(max-width:640px){.two-col{grid-template-columns:1fr}}
  .full{width:100%}
  .mt8{margin-top:8px}
  .mt4{margin-top:4px}
  .row{display:flex;align-items:center;gap:8px}
  .row-between{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px}
`;

// ── Constants ─────────────────────────────────────────────────────────────────
const RESTAURANTS = [
  { id: 1, name: 'Bikanervala',   emoji: '🍛', amountPaise: 36000, items: ['Dal Makhani', 'Paneer Tikka'],     lat: 28.6353, lng: 77.2245 },
  { id: 2, name: 'Burger Singh',  emoji: '🍔', amountPaise: 42700, items: ['Classic Burger', 'Masala Fries'],  lat: 28.6127, lng: 77.2295 },
  { id: 3, name: 'Pizza Palace',  emoji: '🍕', amountPaise: 55000, items: ['Margherita', 'Garlic Bread'],      lat: 28.6273, lng: 77.2160 },
  { id: 4, name: 'Chai Sutta',    emoji: '☕', amountPaise: 15000, items: ['Masala Chai', 'Bun Maska'],        lat: 28.6412, lng: 77.2350 },
];

const USER_LAT = 28.5700;
const USER_LNG = 77.3200;

// ── Auth screen ───────────────────────────────────────────────────────────────
function AuthScreen({ onSuccess }) {
  const [mode, setMode] = useState('login');
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState(null);
  const [form, setForm] = useState({ email: '', password: '', username: '' });
  const set = k => e => setForm(f => ({ ...f, [k]: e.target.value }));

  const submit = async e => {
    e.preventDefault();
    setLoading(true);
    setMsg(null);
    try {
      if (mode === 'register') {
        await userAPI.post('/auth/register', {
          email: form.email,
          password: form.password,
          username: form.username || form.email.split('@')[0].replace(/[^a-z0-9]/gi, '') || 'user',
        });
        const res = await userAPI.post('/auth/login', { email: form.email, password: form.password });
        _storeAuth(res.data);
        onSuccess(res.data);
      } else {
        const res = await userAPI.post('/auth/login', { email: form.email, password: form.password });
        _storeAuth(res.data);
        onSuccess(res.data);
      }
    } catch (err) {
      const detail = err.response?.data?.error?.message
        || (Array.isArray(err.response?.data?.detail) ? err.response.data.detail[0]?.msg : err.response?.data?.detail)
        || err.message;
      setMsg({ ok: false, text: String(detail) });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-screen">
      <div className="login-card">
        <div className="login-title">🛵 FoodDelivery Hub</div>
        <div className="login-sub">{mode === 'login' ? 'Sign in to continue' : 'Create your account'}</div>
        {msg && <div className={`msg ${msg.ok ? 'ok' : 'err'}`}>{msg.text}</div>}
        <form onSubmit={submit}>
          {mode === 'register' && (
            <div className="form-group">
              <label>Username</label>
              <input value={form.username} onChange={set('username')} placeholder="johndoe" />
            </div>
          )}
          <div className="form-group">
            <label>Email</label>
            <input type="email" value={form.email} onChange={set('email')} required />
          </div>
          <div className="form-group">
            <label>Password {mode === 'register' && <span style={{fontWeight:400,color:'var(--text2)'}}>(min 6 chars)</span>}</label>
            <input type="password" value={form.password} onChange={set('password')} required />
          </div>
          <button className="btn full" type="submit" disabled={loading}>
            {loading ? '…' : mode === 'login' ? 'Sign In' : 'Sign Up'}
          </button>
        </form>
        <button className="btn btn-ghost full mt8"
          onClick={() => { setMode(m => m === 'login' ? 'register' : 'login'); setMsg(null); }}>
          {mode === 'login' ? "Don't have an account? Sign up" : 'Already have an account? Sign in'}
        </button>
      </div>
    </div>
  );
}

function _storeAuth(d) {
  localStorage.setItem('auth_token', d.access_token);
  localStorage.setItem('user_email', d.email);
  localStorage.setItem('user_name', d.username || d.email);
}

// ── Helpers ───────────────────────────────────────────────────────────────────
const fmt = paise => `₹${(paise / 100).toFixed(0)}`;

// ── Step indicator ────────────────────────────────────────────────────────────
const STEPS = ['select', 'review', 'dispatch', 'done'];
const STEP_LABELS = { select: '1. Choose', review: '2. Payment', dispatch: '3. Dispatch', done: '✓ Done' };

function StepBar({ current }) {
  const ci = STEPS.indexOf(current);
  return (
    <div className="steps">
      {STEPS.map((s, i) => (
        <React.Fragment key={s}>
          <span className={`step-pill ${i < ci ? 'done' : i === ci ? 'active' : ''}`}>
            {i < ci ? '✓ ' : ''}{STEP_LABELS[s]}
          </span>
          {i < STEPS.length - 1 && <span className="step-arrow">›</span>}
        </React.Fragment>
      ))}
    </div>
  );
}

// ── Order tab ─────────────────────────────────────────────────────────────────
function OrderTab({ onOrderPlaced }) {
  const [step, setStep] = useState('select');
  const [selected, setSelected] = useState(RESTAURANTS[0]);
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState(null);
  const [dispatchId, setDispatchId] = useState(null);
  const sseRef = useRef(null);
  const logRef = useRef(null);

  const email = localStorage.getItem('user_email') || 'user@example.com';
  const name  = localStorage.getItem('user_name')  || 'Customer';

  const addEv = useCallback((type, text) => {
    setEvents(prev => [...prev, { type, text, ts: new Date().toLocaleTimeString() }]);
    setTimeout(() => logRef.current?.scrollTo(0, logRef.current.scrollHeight), 40);
  }, []);

  const confirmPayment = async () => {
    setLoading(true);
    setMsg(null);
    setEvents([]);
    const orderId = `ord_${Date.now()}`;
    try {
      // ── Step 1: Payment (simulate — no Stripe card form needed in dev) ──
      setStep('dispatch');
      addEv('info', `Processing payment for ${selected.name}…`);

      const payRes = await paymentAPI.post('/payments/simulate', {
        order_id:        orderId,
        amount:          selected.amountPaise,
        currency:        'inr',
        customer_email:  email,
        customer_name:   name,
        restaurant_name: selected.name,
        items:           selected.items,
        user_lat:        USER_LAT,
        user_lng:        USER_LNG,
        restaurant_lat:  selected.lat,
        restaurant_lng:  selected.lng,
      });
      addEv('ok', `Payment succeeded  ·  ref: ${payRes.data.payment_intent_id.slice(0, 22)}…`);
      addEv('info', 'PaymentSuccessEvent → Celery queue → restaurant + dispatch notified');

      // ── Step 2: Place order with dispatch service ──
      addEv('info', 'Placing order with Dispatch Service…');
      const dispRes = await dispatchAPI.post('/api/order/place', {
        customer_name:  name,
        user_x:         USER_LAT,
        user_y:         USER_LNG,
        restaurant:     selected.name,
        restaurant_x:   selected.lat,
        restaurant_y:   selected.lng,
        items:          selected.items,
        amount:         selected.amountPaise / 100,
      });
      const dId = dispRes.data.order_id;
      setDispatchId(dId);
      addEv('ok', `Dispatch order created  ·  ID: ${dId}`);

      // ── Step 3: Subscribe to SSE stream ──
      addEv('info', 'Subscribing to real-time dispatch events…');
      const sse = new EventSource(`${API_DISPATCH}/api/order/${dId}/stream`);
      sseRef.current = sse;
      sse.onmessage = e => {
        try {
          const d = JSON.parse(e.data);
          if (d.type === 'done') {
            addEv('ok', 'Dispatch complete — rider assigned!');
            sse.close();
            setStep('done');
            onOrderPlaced({ orderId, restaurant: selected.name, amount: selected.amountPaise, status: 'dispatched' });
          } else if (d.type === 'error') {
            addEv('err', d.msg || 'Dispatch error');
            sse.close();
          } else {
            const bad = ['rejected', 'timeout', 'failed'].includes(d.type);
            addEv(bad ? 'err' : 'ok', `[${d.type}] ${d.msg || d.rider_name || JSON.stringify(d)}`);
          }
        } catch { addEv('info', e.data); }
      };
      sse.onerror = () => { addEv('err', 'SSE connection lost'); sse.close(); };
    } catch (err) {
      const detail = err.response?.data?.detail || err.message;
      setMsg({ ok: false, text: String(detail) });
      addEv('err', String(detail));
      setStep('review');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => () => sseRef.current?.close(), []);

  const reset = () => { setStep('select'); setEvents([]); setMsg(null); setDispatchId(null); };

  return (
    <div>
      <StepBar current={step} />
      {msg && <div className="msg err">{msg.text}</div>}

      {/* ── STEP 1: Select ─────────────────────────────── */}
      {step === 'select' && (
        <div className="card">
          <div className="card-title">Choose a Restaurant</div>
          <div className="rest-grid">
            {RESTAURANTS.map(r => (
              <div key={r.id} className={`rest-card ${selected.id === r.id ? 'sel' : ''}`}
                onClick={() => setSelected(r)}>
                <div className="rest-emoji">{r.emoji}</div>
                <div className="rest-name">{r.name}</div>
                <div className="rest-price">{fmt(r.amountPaise)}</div>
                <div className="rest-items">{r.items.join(', ')}</div>
              </div>
            ))}
          </div>
          <button className="btn full" onClick={() => setStep('review')}>
            Continue to Payment →
          </button>
        </div>
      )}

      {/* ── STEP 2: Payment review ──────────────────────── */}
      {step === 'review' && (
        <div className="two-col">
          <div className="card">
            <div className="card-title">Order Summary</div>
            <div className="pay-box">
              <div className="pay-row">
                <span>{selected.emoji} {selected.name}</span>
                <span>{fmt(selected.amountPaise)}</span>
              </div>
              {selected.items.map(it => (
                <div className="pay-row" key={it} style={{color:'var(--text2)'}}>
                  <span style={{paddingLeft:12}}>· {it}</span>
                  <span></span>
                </div>
              ))}
              <div className="pay-row" style={{color:'var(--text2)'}}>
                <span>Delivery fee</span><span>₹0</span>
              </div>
              <div className="pay-row">
                <span>Total</span><span>{fmt(selected.amountPaise)}</span>
              </div>
            </div>
            <div style={{fontSize:11,color:'var(--text2)',marginBottom:14}}>
              Delivering to: <strong style={{color:'var(--text)'}}>Your Location</strong>
              &nbsp;&nbsp;·&nbsp;&nbsp;{USER_LAT}°N, {USER_LNG}°E
            </div>
            <button className="btn full" onClick={() => setStep('select')} style={{marginBottom:8}}>
              ← Change Restaurant
            </button>
          </div>

          <div className="card">
            <div className="card-title">Payment</div>
            <div className="pay-badge" style={{marginBottom:14}}>
              🔧 DEVELOPMENT MODE — Simulated Payment
            </div>
            <div style={{fontSize:12,color:'var(--text2)',marginBottom:16,lineHeight:1.6}}>
              In production, a Stripe payment form appears here and the customer
              enters their card details. For this demo, payment is simulated
              instantly — no real card is charged.
            </div>
            <div className="pay-box">
              <div className="pay-row"><span>Method</span><span>💳 Simulated Visa ····4242</span></div>
              <div className="pay-row"><span>Amount</span><span style={{color:'var(--brand)',fontWeight:700}}>{fmt(selected.amountPaise)}</span></div>
              <div className="pay-row"><span>Currency</span><span>INR</span></div>
              <div className="pay-row"><span>Billing</span><span>{email}</span></div>
            </div>
            <button className="btn btn-green full" onClick={confirmPayment} disabled={loading}>
              {loading ? '⏳ Processing…' : `Confirm & Pay ${fmt(selected.amountPaise)}`}
            </button>
          </div>
        </div>
      )}

      {/* ── STEP 3 + DONE: Dispatch stream ─────────────── */}
      {(step === 'dispatch' || step === 'done') && (
        <div className="two-col">
          <div className="card">
            <div className="card-title">
              {step === 'done' ? '✅ Order Placed!' : '🛵 Assigning Rider…'}
            </div>
            <div className="pay-box">
              <div className="pay-row"><span>Restaurant</span><span>{selected.emoji} {selected.name}</span></div>
              <div className="pay-row"><span>Amount</span><span>{fmt(selected.amountPaise)}</span></div>
              <div className="pay-row"><span>Status</span>
                <span style={{color: step === 'done' ? 'var(--green)' : 'var(--yellow)'}}>
                  {step === 'done' ? 'Rider Assigned' : 'Finding Rider…'}
                </span>
              </div>
              {dispatchId && <div className="pay-row" style={{color:'var(--text2)',fontSize:11}}>
                <span>Dispatch ID</span><span>{dispatchId}</span>
              </div>}
            </div>
            {step === 'done' && (
              <button className="btn btn-ghost full mt8" onClick={reset}>Place Another Order</button>
            )}
          </div>

          <div className="card">
            <div className="card-title">Live Dispatch Events</div>
            <div className="event-log" ref={logRef}>
              {events.length === 0
                ? <span style={{color:'var(--text2)'}}>Waiting for events…</span>
                : events.map((ev, i) => (
                  <div key={i} className="ev">
                    <span className={`ev-badge ev-${ev.type === 'ok' ? 'ok' : ev.type === 'err' ? 'err' : 'info'}`}>
                      {ev.type}
                    </span>
                    <span style={{color:'var(--text2)',marginRight:5}}>{ev.ts}</span>
                    {ev.text}
                  </div>
                ))
              }
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ── History tab ───────────────────────────────────────────────────────────────
function HistoryTab({ orders }) {
  const dotColor = s => s === 'dispatched' ? 'var(--green)' : s === 'paying' ? 'var(--yellow)' : 'var(--red)';
  return (
    <div className="card">
      <div className="card-title">Order History</div>
      {orders.length === 0
        ? <div style={{color:'var(--text2)'}}>No orders yet — place your first order!</div>
        : orders.map((o, i) => (
          <div key={i} className="hist-row">
            <div className="dot" style={{background: dotColor(o.status)}} />
            <div style={{flex:1}}>
              <div style={{fontWeight:700}}>{o.restaurant}</div>
              <div style={{color:'var(--text2)',fontSize:11}}>{o.orderId}</div>
            </div>
            <div style={{textAlign:'right'}}>
              <div style={{fontWeight:700,color:'var(--brand)'}}>{fmt(o.amount)}</div>
              <div style={{color:'var(--text2)',fontSize:11,textTransform:'capitalize'}}>{o.status}</div>
            </div>
          </div>
        ))
      }
    </div>
  );
}

// ── Riders tab ────────────────────────────────────────────────────────────────
function RidersTab() {
  const [riders, setRiders] = useState([]);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await dispatchAPI.get('/api/riders');
      // API returns { riders: [...], user: {...} }
      const raw = res.data.riders;
      setRiders(Array.isArray(raw) ? raw : Object.values(raw || {}));
      setMsg(null);
    } catch (e) {
      setMsg('Could not reach Dispatch Service — is it running?');
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const action = async (fn) => { try { await fn(); await load(); } catch {} };

  // Rider status comes as lowercase "idle"/"busy"/"offline"
  const dotColor = s => {
    const st = (s || '').toLowerCase();
    if (st === 'idle')    return 'var(--green)';
    if (st === 'busy')    return 'var(--red)';
    return 'var(--yellow)';
  };
  const statusLabel = s => (s || '').toUpperCase();

  return (
    <div className="card">
      <div className="row-between">
        <div className="card-title" style={{margin:0}}>Rider Fleet</div>
        <div className="row">
          <button className="btn btn-ghost btn-sm"
            onClick={() => action(() => dispatchAPI.post('/api/init'))}>
            Randomize 5
          </button>
          <button className="btn btn-ghost btn-sm"
            onClick={() => action(() => dispatchAPI.post('/api/reset'))}>
            Reset All
          </button>
          <button className="btn btn-ghost btn-sm" onClick={load} disabled={loading}>
            {loading ? '…' : '↻ Refresh'}
          </button>
        </div>
      </div>

      {msg && <div className="msg err mt8">{msg}</div>}

      <div className="mt8">
        {riders.length === 0
          ? <div style={{color:'var(--text2)',marginTop:12}}>No riders — click "Randomize 5" to add demo riders.</div>
          : riders.map(r => (
            <div key={r.id} className="rider-row">
              <div className="dot" style={{background: dotColor(r.status)}} />
              <div style={{flex:1}}>
                <div style={{fontWeight:700}}>{r.name}
                  <span style={{color:'var(--text2)',fontWeight:400,marginLeft:8,fontSize:11}}>
                    #{r.id}
                  </span>
                </div>
                <div style={{color:'var(--text2)',fontSize:11}}>
                  pos ({Number(r.x).toFixed(1)}, {Number(r.y).toFixed(1)})
                  &nbsp;·&nbsp;
                  ⭐ {Number(r.rating).toFixed(1)}
                  &nbsp;·&nbsp;
                  {r.phone}
                </div>
              </div>
              <span style={{
                color: dotColor(r.status), fontWeight:700, fontSize:11,
                minWidth:50, textAlign:'right',
              }}>
                {statusLabel(r.status)}
              </span>
              {(r.status || '').toLowerCase() !== 'idle' && (
                <button className="btn btn-ghost btn-sm"
                  onClick={() => action(() => dispatchAPI.post(`/api/riders/${r.id}/free`))}>
                  Free
                </button>
              )}
            </div>
          ))
        }
      </div>
    </div>
  );
}

// ── Root ──────────────────────────────────────────────────────────────────────
export default function App() {
  const [auth, setAuth]     = useState(false);
  const [ready, setReady]   = useState(false);
  const [tab, setTab]       = useState('order');
  const [orders, setOrders] = useState([]);

  useEffect(() => { if (localStorage.getItem('auth_token')) setAuth(true); setReady(true); }, []);

  const addOrder = useCallback(o => setOrders(p => [o, ...p]), []);

  if (!ready) return null;

  if (!auth) return (
    <>
      <style>{CSS}</style>
      <AuthScreen onSuccess={d => { _storeAuth(d); setAuth(true); }} />
    </>
  );

  const TABS = [
    { id: 'order',   label: '🛵 Place Order' },
    { id: 'history', label: `📋 History${orders.length ? ` (${orders.length})` : ''}` },
    { id: 'riders',  label: '🚴 Riders' },
  ];

  return (
    <>
      <style>{CSS}</style>
      <div className="app">
        <header className="header">
          <div className="logo">🛵 FoodDelivery Hub</div>
          <div className="tabs">
            {TABS.map(t => (
              <button key={t.id} className={`tab ${tab === t.id ? 'active' : ''}`}
                onClick={() => setTab(t.id)}>{t.label}</button>
            ))}
          </div>
          <div className="user-info">
            👤 {localStorage.getItem('user_name')}
            <button className="logout-btn"
              onClick={() => { localStorage.clear(); window.location.reload(); }}>
              Logout
            </button>
          </div>
        </header>
        <div className="content">
          {tab === 'order'   && <OrderTab onOrderPlaced={addOrder} />}
          {tab === 'history' && <HistoryTab orders={orders} />}
          {tab === 'riders'  && <RidersTab />}
        </div>
      </div>
    </>
  );
}
