import { useState, useEffect, useRef, useCallback } from "react";
import { MapContainer, TileLayer, Marker, Popup, Polyline, Circle, useMap } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

// Fix Leaflet default icon issue with bundlers
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

// --- Custom SVG Icons ---
const createSvgIcon = (svg, size = [36, 36], anchor = [18, 36]) =>
  L.divIcon({
    html: svg,
    className: "",
    iconSize: size,
    iconAnchor: anchor,
    popupAnchor: [0, -36],
  });

const CUSTOMER_ICON = createSvgIcon(`
  <svg width="36" height="44" viewBox="0 0 36 44" xmlns="http://www.w3.org/2000/svg">
    <filter id="shadow"><feDropShadow dx="0" dy="2" stdDeviation="2" flood-opacity="0.3"/></filter>
    <path d="M18 0C8.06 0 0 8.06 0 18c0 13.5 18 26 18 26S36 31.5 36 18C36 8.06 27.94 0 18 0z" fill="#f97316" filter="url(#shadow)"/>
    <circle cx="18" cy="17" r="7" fill="white"/>
    <circle cx="18" cy="17" r="4" fill="#f97316"/>
  </svg>`, [36, 44], [18, 44]);

const RIDER_ICON = createSvgIcon(`
  <svg width="32" height="40" viewBox="0 0 32 40" xmlns="http://www.w3.org/2000/svg">
    <filter id="shadow2"><feDropShadow dx="0" dy="2" stdDeviation="2" flood-opacity="0.3"/></filter>
    <path d="M16 0C7.16 0 0 7.16 0 16c0 12 16 24 16 24S32 28 32 16C32 7.16 24.84 0 16 0z" fill="#3b82f6" filter="url(#shadow2)"/>
    <text x="16" y="21" text-anchor="middle" font-size="14" fill="white">🏍️</text>
  </svg>`, [32, 40], [16, 40]);

const ASSIGNED_RIDER_ICON = createSvgIcon(`
  <svg width="32" height="40" viewBox="0 0 32 40" xmlns="http://www.w3.org/2000/svg">
    <filter id="shadow3"><feDropShadow dx="0" dy="2" stdDeviation="2" flood-opacity="0.3"/></filter>
    <path d="M16 0C7.16 0 0 7.16 0 16c0 12 16 24 16 24S32 28 32 16C32 7.16 24.84 0 16 0z" fill="#22c55e" filter="url(#shadow3)"/>
    <text x="16" y="21" text-anchor="middle" font-size="14" fill="white">✅</text>
  </svg>`, [32, 40], [16, 40]);

// --- Map recenter helper ---
function RecenterMap({ center }) {
  const map = useMap();
  useEffect(() => {
    if (center) map.flyTo(center, 13, { duration: 1.2 });
  }, [center, map]);
  return null;
}

// --- Noida city boundary (approximate polygon) ---
const NOIDA_BOUNDARY = [
  [28.6448, 77.3910], [28.6600, 77.4100], [28.6750, 77.4300],
  [28.6800, 77.4600], [28.6600, 77.4900], [28.6300, 77.5100],
  [28.5900, 77.5000], [28.5600, 77.4700], [28.5500, 77.4200],
  [28.5700, 77.3900], [28.6100, 77.3750], [28.6448, 77.3910],
];

// --- Rider mock data with real Noida coords ---
const MOCK_RIDERS = [
  { id: "R1", name: "Vikram Singh",    rating: 4.8, lat: 28.6350, lng: 77.4120, idle_time: 12, status: "idle" },
  { id: "R2", name: "Priya Sharma",   rating: 4.9, lat: 28.6200, lng: 77.4350, idle_time: 25, status: "idle" },
  { id: "R3", name: "Arjun Mehta",    rating: 4.5, lat: 28.6450, lng: 77.3950, idle_time: 5,  status: "idle" },
  { id: "R4", name: "Neha Gupta",     rating: 4.7, lat: 28.6100, lng: 77.4600, idle_time: 18, status: "idle" },
  { id: "R5", name: "Ravi Kumar",     rating: 4.6, lat: 28.6600, lng: 77.4400, idle_time: 30, status: "idle" },
  { id: "R6", name: "Sneha Patel",    rating: 4.8, lat: 28.5950, lng: 77.4200, idle_time: 8,  status: "idle" },
  { id: "R7", name: "Deepak Verma",   rating: 4.4, lat: 28.6300, lng: 77.4700, idle_time: 40, status: "idle" },
  { id: "R8", name: "Kavya Nair",     rating: 4.9, lat: 28.6550, lng: 77.3850, idle_time: 15, status: "idle" },
];

// Customer-selectable locations in Noida
const NOIDA_LOCATIONS = [
  { label: "Sector 18 Market",    lat: 28.5706, lng: 77.3219 },
  { label: "Noida City Centre",   lat: 28.5745, lng: 77.3590 },
  { label: "Sector 62",           lat: 28.6270, lng: 77.3716 },
  { label: "Sector 137",          lat: 28.5188, lng: 77.3840 },
  { label: "DLF Mall of India",   lat: 28.5672, lng: 77.3210 },
  { label: "Botanical Garden",    lat: 28.5588, lng: 77.3374 },
  { label: "Greater Noida West",  lat: 28.6130, lng: 77.4310 },
  { label: "Sector 50",           lat: 28.6060, lng: 77.3630 },
];

function haversineDistance(lat1, lng1, lat2, lng2) {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
    Math.cos((lat2 * Math.PI) / 180) *
    Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function computeScore(rider, customerLat, customerLng) {
  const dist = haversineDistance(rider.lat, rider.lng, customerLat, customerLng);
  return 0.5 * dist + 0.3 * (1 / rider.rating) + 0.2 * (1 / (rider.idle_time + 1));
}

function rankRiders(riders, customerLat, customerLng) {
  return [...riders]
    .map((r) => ({ ...r, score: computeScore(r, customerLat, customerLng) }))
    .sort((a, b) => a.score - b.score);
}

// Simple straight-line route (in production, use OSRM or Valhalla API)
function buildRoute(rider, customer) {
  return [
    [rider.lat, rider.lng],
    [customer.lat, customer.lng],
  ];
}

export default function App() {
  const [riders, setRiders] = useState(MOCK_RIDERS);
  const [customerLocation, setCustomerLocation] = useState(null);
  const [selectedLocationIdx, setSelectedLocationIdx] = useState("");
  const [orderStatus, setOrderStatus] = useState("idle"); // idle | searching | assigned | failed
  const [assignedRider, setAssignedRider] = useState(null);
  const [logs, setLogs] = useState([]);
  const [mapCenter, setMapCenter] = useState([28.6139, 77.4200]);
  const [route, setRoute] = useState(null);
  const logsEndRef = useRef(null);

  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [logs]);

  const addLog = useCallback((icon, msg) => {
    const time = new Date().toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
    setLogs((prev) => [...prev, { time, icon, msg, id: Date.now() + Math.random() }]);
  }, []);

  function handleLocationSelect(e) {
    const idx = e.target.value;
    setSelectedLocationIdx(idx);
    if (idx === "") return;
    const loc = NOIDA_LOCATIONS[parseInt(idx)];
    setCustomerLocation(loc);
    setMapCenter([loc.lat, loc.lng]);
    setOrderStatus("idle");
    setAssignedRider(null);
    setRoute(null);
    setLogs([]);
  }

  async function handlePlaceOrder() {
    if (!customerLocation) return;
    setOrderStatus("searching");
    setAssignedRider(null);
    setRoute(null);
    setLogs([]);

    const orderId = "ORD-" + Math.random().toString(36).substring(2, 7).toUpperCase();
    addLog("📦", `Order received: ${orderId}`);
    await sleep(600);
    addLog("🔍", "Scanning for available riders...");
    await sleep(800);

    const ranked = rankRiders(riders, customerLocation.lat, customerLocation.lng);
    addLog("📊", `Found ${ranked.length} available riders. Ranking by score...`);
    await sleep(500);

    let assigned = null;
    for (let i = 0; i < ranked.length; i++) {
      const rider = ranked[i];
      addLog("🏍️", `[${i + 1}/${ranked.length}] Contacting ${rider.name} (score: ${rider.score.toFixed(3)}, dist: ${haversineDistance(rider.lat, rider.lng, customerLocation.lat, customerLocation.lng).toFixed(1)}km)...`);
      const waitMs = 1000 + Math.random() * 1500;
      await sleep(waitMs);

      const rand = Math.random();
      if (rand < 0.70) {
        addLog("✅", `${rider.name} accepted! Assigned to your order.`);
        assigned = rider;
        break;
      } else if (rand < 0.90) {
        addLog("🚫", `${rider.name} rejected the order.`);
      } else {
        addLog("⏱️", `${rider.name} timed out (no response).`);
      }
    }

    if (assigned) {
      setAssignedRider(assigned);
      setRoute(buildRoute(assigned, customerLocation));
      setRiders((prev) =>
        prev.map((r) => (r.id === assigned.id ? { ...r, status: "assigned" } : r))
      );
      setOrderStatus("assigned");
      addLog("🎉", `Rider is on the way! ETA: ${Math.ceil(haversineDistance(assigned.lat, assigned.lng, customerLocation.lat, customerLocation.lng) * 3)} mins`);
    } else {
      setOrderStatus("failed");
      addLog("❌", "No riders available. Please try again.");
    }
  }

  function handleReset() {
    setOrderStatus("idle");
    setAssignedRider(null);
    setRoute(null);
    setLogs([]);
    setCustomerLocation(null);
    setSelectedLocationIdx("");
    setRiders(MOCK_RIDERS);
    setMapCenter([28.6139, 77.4200]);
  }

  const statusColors = {
    idle: "#64748b",
    searching: "#f59e0b",
    assigned: "#22c55e",
    failed: "#ef4444",
  };

  const statusLabels = {
    idle: "Waiting for Order",
    searching: "Finding Rider...",
    assigned: "Rider Assigned ✓",
    failed: "No Riders Available",
  };

  return (
    <div style={styles.root}>
      {/* Header */}
      <header style={styles.header}>
        <div style={styles.headerInner}>
          <div style={styles.logo}>
            <span style={styles.logoIcon}>⚡</span>
            <span style={styles.logoText}>SwiftDispatch</span>
            <span style={styles.logoBadge}>Distributed Demo</span>
          </div>
          <div style={{ ...styles.statusBadge, background: statusColors[orderStatus] + "22", color: statusColors[orderStatus], border: `1px solid ${statusColors[orderStatus]}44` }}>
            {orderStatus === "searching" && <span style={styles.pulse} />}
            {statusLabels[orderStatus]}
          </div>
        </div>
      </header>

      <main style={styles.main}>
        {/* Left Panel */}
        <aside style={styles.sidebar}>
          <section style={styles.card}>
            <h2 style={styles.cardTitle}>📍 Place Order</h2>
            <label style={styles.label}>Select Delivery Location</label>
            <select
              style={styles.select}
              value={selectedLocationIdx}
              onChange={handleLocationSelect}
              disabled={orderStatus === "searching"}
            >
              <option value="">— Choose a location —</option>
              {NOIDA_LOCATIONS.map((loc, i) => (
                <option key={i} value={i}>{loc.label}</option>
              ))}
            </select>

            {customerLocation && (
              <div style={styles.coordBox}>
                <span style={styles.coordLabel}>📌 {NOIDA_LOCATIONS[selectedLocationIdx]?.label}</span>
                <span style={styles.coordVal}>{customerLocation.lat.toFixed(4)}°N, {customerLocation.lng.toFixed(4)}°E</span>
              </div>
            )}

            <button
              style={{
                ...styles.btn,
                ...((!customerLocation || orderStatus === "searching") ? styles.btnDisabled : {}),
                ...(orderStatus === "assigned" ? styles.btnSuccess : {}),
              }}
              onClick={handlePlaceOrder}
              disabled={!customerLocation || orderStatus === "searching"}
            >
              {orderStatus === "searching" ? "🔄 Dispatching..." : orderStatus === "assigned" ? "✅ Order Assigned!" : "🚀 Place Order"}
            </button>

            {(orderStatus === "assigned" || orderStatus === "failed") && (
              <button style={styles.btnReset} onClick={handleReset}>↩ Reset</button>
            )}
          </section>

          {/* Rider Leaderboard */}
          <section style={styles.card}>
            <h2 style={styles.cardTitle}>🏍️ Riders in Area</h2>
            <div style={styles.riderList}>
              {(customerLocation
                ? rankRiders(riders, customerLocation.lat, customerLocation.lng)
                : riders
              ).map((r) => {
                const dist = customerLocation
                  ? haversineDistance(r.lat, r.lng, customerLocation.lat, customerLocation.lng).toFixed(1)
                  : null;
                const isAssigned = assignedRider?.id === r.id;
                return (
                  <div
                    key={r.id}
                    style={{
                      ...styles.riderRow,
                      ...(isAssigned ? styles.riderRowAssigned : {}),
                    }}
                  >
                    <span style={styles.riderName}>{isAssigned ? "✅ " : "🏍️ "}{r.name}</span>
                    <div style={styles.riderMeta}>
                      <span>⭐ {r.rating}</span>
                      {dist && <span>📍 {dist} km</span>}
                    </div>
                  </div>
                );
              })}
            </div>
          </section>
        </aside>

        {/* Map */}
        <div style={styles.mapWrapper}>
          <MapContainer
            center={mapCenter}
            zoom={12}
            style={{ width: "100%", height: "100%" }}
            zoomControl={true}
          >
            <TileLayer
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            />
            <RecenterMap center={mapCenter} />

            {/* City boundary */}
            <Polyline
              positions={NOIDA_BOUNDARY}
              pathOptions={{ color: "#f97316", weight: 2, dashArray: "8 4", opacity: 0.6 }}
            />

            {/* Rider markers */}
            {riders.map((rider) => {
              const isAssigned = assignedRider?.id === rider.id;
              return (
                <Marker
                  key={rider.id}
                  position={[rider.lat, rider.lng]}
                  icon={isAssigned ? ASSIGNED_RIDER_ICON : RIDER_ICON}
                >
                  <Popup>
                    <div style={{ fontFamily: "sans-serif", minWidth: 140 }}>
                      <strong>{rider.name}</strong><br />
                      ⭐ Rating: {rider.rating}<br />
                      ⏱️ Idle: {rider.idle_time} min
                      {customerLocation && (
                        <>
                          <br />
                          📍 {haversineDistance(rider.lat, rider.lng, customerLocation.lat, customerLocation.lng).toFixed(2)} km away
                        </>
                      )}
                      {isAssigned && <><br /><strong style={{ color: "#22c55e" }}>✅ Assigned!</strong></>}
                    </div>
                  </Popup>
                </Marker>
              );
            })}

            {/* Customer location */}
            {customerLocation && (
              <>
                <Marker position={[customerLocation.lat, customerLocation.lng]} icon={CUSTOMER_ICON}>
                  <Popup>
                    <div style={{ fontFamily: "sans-serif" }}>
                      <strong>📦 Delivery Here</strong><br />
                      {NOIDA_LOCATIONS[selectedLocationIdx]?.label}
                    </div>
                  </Popup>
                </Marker>
                <Circle
                  center={[customerLocation.lat, customerLocation.lng]}
                  radius={300}
                  pathOptions={{ color: "#f97316", fillColor: "#f97316", fillOpacity: 0.08, weight: 1 }}
                />
              </>
            )}

            {/* Route line */}
            {route && (
              <Polyline
                positions={route}
                pathOptions={{ color: "#22c55e", weight: 4, opacity: 0.9, dashArray: "12 6" }}
              />
            )}
          </MapContainer>

          {/* Map legend */}
          <div style={styles.legend}>
            <LegendItem color="#3b82f6" label="Rider" />
            <LegendItem color="#22c55e" label="Assigned" />
            <LegendItem color="#f97316" label="Customer" />
            <LegendItem color="#f97316" label="Noida boundary" dashed />
          </div>
        </div>

        {/* Log Panel */}
        <aside style={styles.logPanel}>
          <h2 style={styles.cardTitle}>📋 Dispatch Log</h2>
          <div style={styles.logScroll}>
            {logs.length === 0 && (
              <p style={styles.logEmpty}>Logs will appear here once you place an order.</p>
            )}
            {logs.map((log) => (
              <div key={log.id} style={styles.logEntry}>
                <span style={styles.logTime}>{log.time}</span>
                <span style={styles.logMsg}>{log.icon} {log.msg}</span>
              </div>
            ))}
            <div ref={logsEndRef} />
          </div>

          {assignedRider && (
            <div style={styles.assignedCard}>
              <div style={styles.assignedTitle}>🎉 Rider Assigned</div>
              <div style={styles.assignedName}>{assignedRider.name}</div>
              <div style={styles.assignedMeta}>⭐ {assignedRider.rating} · 📍 {haversineDistance(assignedRider.lat, assignedRider.lng, customerLocation.lat, customerLocation.lng).toFixed(1)} km away</div>
              <div style={styles.assignedEta}>ETA: ~{Math.ceil(haversineDistance(assignedRider.lat, assignedRider.lng, customerLocation.lat, customerLocation.lng) * 3)} mins</div>
            </div>
          )}
        </aside>
      </main>
    </div>
  );
}

function LegendItem({ color, label, dashed }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12 }}>
      <div style={{
        width: 24, height: 3, borderRadius: 2,
        background: dashed ? "transparent" : color,
        border: dashed ? `2px dashed ${color}` : "none",
      }} />
      <span style={{ color: "#94a3b8" }}>{label}</span>
    </div>
  );
}

function sleep(ms) {
  return new Promise((res) => setTimeout(res, ms));
}

// --- Styles ---
const styles = {
  root: { display: "flex", flexDirection: "column", height: "100vh", background: "#0f172a", color: "#e2e8f0", fontFamily: "'DM Sans', sans-serif", overflow: "hidden" },
  header: { background: "#1e293b", borderBottom: "1px solid #334155", padding: "0 24px", height: 56, display: "flex", alignItems: "center", flexShrink: 0 },
  headerInner: { display: "flex", alignItems: "center", justifyContent: "space-between", width: "100%" },
  logo: { display: "flex", alignItems: "center", gap: 10 },
  logoIcon: { fontSize: 22 },
  logoText: { fontSize: 20, fontWeight: 700, color: "#f1f5f9", letterSpacing: "-0.5px" },
  logoBadge: { fontSize: 11, background: "#f97316", color: "white", borderRadius: 4, padding: "2px 7px", fontWeight: 600, letterSpacing: "0.5px" },
  statusBadge: { display: "flex", alignItems: "center", gap: 7, fontSize: 13, fontWeight: 600, borderRadius: 20, padding: "5px 14px" },
  pulse: { width: 8, height: 8, borderRadius: "50%", background: "#f59e0b", animation: "pulse 1s infinite" },
  main: { display: "grid", gridTemplateColumns: "280px 1fr 300px", flex: 1, overflow: "hidden" },
  sidebar: { background: "#1e293b", borderRight: "1px solid #334155", overflowY: "auto", padding: 16, display: "flex", flexDirection: "column", gap: 16 },
  card: { background: "#0f172a", borderRadius: 10, padding: 16, border: "1px solid #1e293b" },
  cardTitle: { fontSize: 13, fontWeight: 700, color: "#94a3b8", textTransform: "uppercase", letterSpacing: "0.8px", margin: "0 0 12px 0" },
  label: { display: "block", fontSize: 12, color: "#64748b", marginBottom: 6 },
  select: { width: "100%", background: "#1e293b", border: "1px solid #334155", color: "#e2e8f0", borderRadius: 7, padding: "9px 10px", fontSize: 13, cursor: "pointer", marginBottom: 12 },
  coordBox: { background: "#1e293b", borderRadius: 7, padding: "8px 12px", marginBottom: 12, display: "flex", flexDirection: "column", gap: 2 },
  coordLabel: { fontSize: 13, fontWeight: 600, color: "#f97316" },
  coordVal: { fontSize: 11, color: "#64748b", fontFamily: "monospace" },
  btn: { width: "100%", background: "linear-gradient(135deg, #f97316, #ea580c)", color: "white", border: "none", borderRadius: 8, padding: "11px 0", fontSize: 14, fontWeight: 700, cursor: "pointer", transition: "opacity 0.2s", marginBottom: 8 },
  btnDisabled: { opacity: 0.4, cursor: "not-allowed" },
  btnSuccess: { background: "linear-gradient(135deg, #22c55e, #16a34a)" },
  btnReset: { width: "100%", background: "#1e293b", color: "#94a3b8", border: "1px solid #334155", borderRadius: 8, padding: "9px 0", fontSize: 13, cursor: "pointer" },
  riderList: { display: "flex", flexDirection: "column", gap: 6 },
  riderRow: { background: "#1e293b", borderRadius: 7, padding: "8px 10px", border: "1px solid #334155", transition: "border-color 0.3s" },
  riderRowAssigned: { border: "1px solid #22c55e", background: "#052e16" },
  riderName: { fontSize: 13, fontWeight: 600, color: "#e2e8f0", display: "block" },
  riderMeta: { display: "flex", gap: 10, fontSize: 11, color: "#64748b", marginTop: 2 },
  mapWrapper: { position: "relative", flex: 1, overflow: "hidden" },
  legend: { position: "absolute", bottom: 20, left: 16, background: "rgba(15,23,42,0.85)", backdropFilter: "blur(8px)", borderRadius: 8, padding: "8px 12px", display: "flex", gap: 14, border: "1px solid #1e293b", zIndex: 999 },
  logPanel: { background: "#1e293b", borderLeft: "1px solid #334155", display: "flex", flexDirection: "column", padding: 16, gap: 12, overflow: "hidden" },
  logScroll: { flex: 1, overflowY: "auto", display: "flex", flexDirection: "column", gap: 6 },
  logEmpty: { fontSize: 12, color: "#475569", fontStyle: "italic", textAlign: "center", marginTop: 24 },
  logEntry: { display: "flex", flexDirection: "column", gap: 1, padding: "6px 8px", background: "#0f172a", borderRadius: 6, borderLeft: "2px solid #334155" },
  logTime: { fontSize: 10, color: "#475569", fontFamily: "monospace" },
  logMsg: { fontSize: 12, color: "#cbd5e1", lineHeight: 1.5 },
  assignedCard: { background: "linear-gradient(135deg, #052e16, #14532d)", border: "1px solid #22c55e44", borderRadius: 10, padding: 14, flexShrink: 0 },
  assignedTitle: { fontSize: 11, fontWeight: 700, color: "#22c55e", textTransform: "uppercase", letterSpacing: "0.8px" },
  assignedName: { fontSize: 18, fontWeight: 700, color: "#f1f5f9", margin: "4px 0 2px" },
  assignedMeta: { fontSize: 12, color: "#86efac" },
  assignedEta: { fontSize: 13, fontWeight: 600, color: "#4ade80", marginTop: 6 },
};
