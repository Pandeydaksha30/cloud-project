@echo off
REM ============================================
REM PROJECT INTEGRATION - MAIN LAUNCHER (Windows)
REM One-command executable for entire project
REM ============================================

setlocal enabledelayedexpansion

REM Colors simulation for Windows (requires Windows 10+)
if "%OS%"=="Windows_NT" (
    echo.
    echo ======================================================================
    echo.
    echo              ^>^> PROJECT INTEGRATION - LAUNCHER ^>^>
    echo.
    echo              Food Delivery Microservices Platform
    echo.
    echo ======================================================================
    echo.
)

REM Check if Docker is installed
docker --version >nul 2>&1
if errorlevel 1 (
    echo Error: Docker is not installed. Please install Docker Desktop first.
    exit /b 1
)

docker-compose --version >nul 2>&1
if errorlevel 1 (
    echo Error: Docker Compose is not installed. Please install Docker Desktop.
    exit /b 1
)

echo Pre-flight checks...

REM Check for required files
if not exist "docker-compose.yml" (
    echo Error: docker-compose.yml not found
    exit /b 1
)

if not exist ".env" (
    echo Warning: .env file not found. Creating from .env.example...
    if exist ".env.example" (
        copy .env.example .env
    ) else (
        echo Error: .env.example not found
        exit /b 1
    )
)

echo OK: All checks passed
echo.

REM Parse command line arguments
set "COMMAND=%1"
set "OPTION=%2"

if "%COMMAND%"=="" set "COMMAND=up"

if /i "%COMMAND%"=="up" (
    echo Starting all services...
    if "%OPTION%"=="--build" (
        echo Building images...
        call docker-compose build
        if errorlevel 1 exit /b 1
    )
    
    echo Waiting for containers to start...
    call docker-compose up -d
    if errorlevel 1 exit /b 1
    
    echo.
    echo ^>^> All services started!
    echo.
    echo Service Endpoints:
    echo.
    echo   ^* User Module:              http://localhost:8001
    echo   ^* CloudPBL Backend:         http://localhost:8002
    echo   ^* Payment Module:           http://localhost:8003
    echo   ^* Restaurant Service:       http://localhost:8004
    echo   ^* Payment Success Consumer: http://localhost:8005
    echo.
    echo   ^* 🚀 UNIFIED FRONTEND:      http://localhost:5173
    echo     ^(Auth + Orders + Files all in one app^)
    echo.
    echo   ^* PostgreSQL:               localhost:5432 ^(postgres:postgres^)
    echo   ^* MongoDB:                  localhost:27017 ^(admin:admin^)
    echo   ^* Redis:                    localhost:6379
    echo.
    echo Tip: View logs with: docker-compose logs -f [service_name]
    goto end
)

if /i "%COMMAND%"=="down" (
    echo Stopping all services...
    call docker-compose down
    if errorlevel 1 exit /b 1
    echo ^>^> Services stopped
    goto end
)

if /i "%COMMAND%"=="restart" (
    echo Restarting all services...
    call docker-compose restart
    if errorlevel 1 exit /b 1
    echo ^>^> Services restarted
    goto end
)

if /i "%COMMAND%"=="logs" (
    if "%OPTION%"=="" (
        echo Showing logs for all services...
        call docker-compose logs -f
    ) else (
        echo Showing logs for %OPTION%...
        call docker-compose logs -f %OPTION%
    )
    goto end
)

if /i "%COMMAND%"=="build" (
    echo Building all services...
    call docker-compose build
    if errorlevel 1 exit /b 1
    echo ^>^> Build complete
    goto end
)

if /i "%COMMAND%"=="ps" (
    echo Running containers:
    call docker-compose ps
    goto end
)

if /i "%COMMAND%"=="clean" (
    echo.
    set /p confirm="Warning: This will delete all data. Continue? (y/N): "
    if /i "!confirm!"=="y" (
        echo Cleaning up...
        call docker-compose down -v
        if errorlevel 1 exit /b 1
        echo ^>^> Cleanup complete
    ) else (
        echo Cancelled
    )
    goto end
)

if /i "%COMMAND%"=="test" (
    echo Running health checks...
    echo.
    echo Testing endpoints...
    
    REM Test endpoints using PowerShell
    powershell -Command ^
        "try { $response = Invoke-WebRequest -Uri 'http://localhost:8001/health' -ErrorAction Stop; Write-Host '  OK User Module' -ForegroundColor Green } catch { Write-Host '  FAIL User Module' -ForegroundColor Red }" 2>nul
    
    powershell -Command ^
        "try { $response = Invoke-WebRequest -Uri 'http://localhost:8002/health' -ErrorAction Stop; Write-Host '  OK CloudPBL Backend' -ForegroundColor Green } catch { Write-Host '  FAIL CloudPBL Backend' -ForegroundColor Red }" 2>nul
    
    echo.
    echo Testing databases...
    
    call docker-compose exec -T postgres pg_isready -U postgres >nul 2>&1
    if errorlevel 1 (
        echo   FAIL PostgreSQL
    ) else (
        echo   OK PostgreSQL
    )
    
    call docker-compose exec -T redis redis-cli ping >nul 2>&1
    if errorlevel 1 (
        echo   FAIL Redis
    ) else (
        echo   OK Redis
    )
    
    echo.
    echo Health check complete
    goto end
)

if /i "%COMMAND%"=="help" (
    echo.
    echo Usage: launcher.bat [command] [options]
    echo.
    echo Commands:
    echo.
    echo   up [--build]    Start all services (optionally rebuild)
    echo   down            Stop all services
    echo   restart         Restart all services
    echo   logs [service]  View logs (all or specific service)
    echo   build           Build all images
    echo   ps              List running containers
    echo   test            Run health checks on all services
    echo   clean           Remove containers and volumes (data loss)
    echo   help            Show this help message
    echo.
    echo Examples:
    echo.
    echo   launcher.bat up                      # Start all services
    echo   launcher.bat up --build              # Rebuild and start
    echo   launcher.bat logs user-module        # View user-module logs
    echo   launcher.bat test                    # Run health checks
    echo   launcher.bat down                    # Stop all services
    echo.
    goto end
)

echo Unknown command: %COMMAND%
echo Try 'launcher.bat help' for usage information
exit /b 1

:end
endlocal
