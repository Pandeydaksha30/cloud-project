import uuid
from datetime import datetime
from typing import Optional

from pydantic import BaseModel, EmailStr, field_validator


class RegisterRequest(BaseModel):
    email: EmailStr
    username: str
    password: str
    tenant_id: Optional[uuid.UUID] = None  # auto-created if not provided
    region: str = "ap-south-1"

    @field_validator("username")
    @classmethod
    def username_length(cls, v: str) -> str:
        v = v.strip()
        if len(v) < 3:
            raise ValueError("Username must be at least 3 characters.")
        if len(v) > 100:
            raise ValueError("Username must be at most 100 characters.")
        return v

    @field_validator("password")
    @classmethod
    def password_strength(cls, v: str) -> str:
        if len(v) < 6:
            raise ValueError("Password must be at least 6 characters.")
        return v


class RegisterResponse(BaseModel):
    user_id: uuid.UUID
    email: str
    username: str
    tenant_id: uuid.UUID
    region: str
    created_at: datetime


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class LoginResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user_id: str
    email: str
    username: str


class ErrorDetail(BaseModel):
    code: str
    message: str
    field: str | None = None
    request_id: str | None = None
    timestamp: datetime


class ErrorResponse(BaseModel):
    error: ErrorDetail
