import base64
import hashlib
import hmac
import json
import time
from datetime import datetime, timezone, timedelta

import bcrypt
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

try:
    from jose import jwt as _jose
    _USE_JOSE = True
except ImportError:
    _jose = None
    _USE_JOSE = False

from app.config import settings
from app.models import Tenant, User
from app.schemas import LoginRequest, LoginResponse, RegisterRequest, RegisterResponse

_TOKEN_EXPIRE_HOURS = 24


class EmailAlreadyExists(Exception):
    pass


class UsernameTaken(Exception):
    pass


class TenantNotFound(Exception):
    pass


class InvalidCredentials(Exception):
    pass


# ── password helpers (direct bcrypt — avoids passlib/bcrypt 4.x incompatibility) ──

def _hash_password(plain: str) -> str:
    return bcrypt.hashpw(plain.encode("utf-8"), bcrypt.gensalt(rounds=12)).decode("utf-8")


def _verify_password(plain: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))
    except Exception:
        return False


# ── JWT helpers ───────────────────────────────────────────────────────────────

def _make_token(user: User) -> str:
    expire = datetime.now(timezone.utc) + timedelta(hours=_TOKEN_EXPIRE_HOURS)
    if _USE_JOSE:
        return _jose.encode(
            {"sub": str(user.user_id), "email": user.email, "username": user.username, "exp": expire},
            settings.SECRET_KEY,
            algorithm="HS256",
        )
    # stdlib fallback when python-jose is not yet installed in the container
    payload = json.dumps({
        "sub": str(user.user_id), "email": user.email,
        "username": user.username, "exp": int(time.time()) + _TOKEN_EXPIRE_HOURS * 3600,
    })
    b64 = base64.urlsafe_b64encode(payload.encode()).decode().rstrip("=")
    sig = hmac.new(settings.SECRET_KEY.encode(), b64.encode(), hashlib.sha256).hexdigest()[:20]
    return f"dev.{b64}.{sig}"


# ── service functions ─────────────────────────────────────────────────────────

async def register_user(db: AsyncSession, payload: RegisterRequest) -> RegisterResponse:
    # Resolve or auto-create tenant
    if payload.tenant_id is None:
        tenant = Tenant(name=f"{payload.username}'s workspace")
        db.add(tenant)
        await db.flush()
    else:
        tenant = await db.get(Tenant, payload.tenant_id)
        if tenant is None:
            raise TenantNotFound(f"Tenant {payload.tenant_id} does not exist.")

    existing_email = await db.scalar(select(User).where(User.email == payload.email.lower()))
    if existing_email:
        raise EmailAlreadyExists(f"Email '{payload.email}' is already registered.")

    existing_username = await db.scalar(
        select(User).where(User.username == payload.username, User.tenant_id == tenant.tenant_id)
    )
    if existing_username:
        raise UsernameTaken(f"Username '{payload.username}' is already taken.")

    new_user = User(
        email=payload.email.lower(),
        username=payload.username,
        password_hash=_hash_password(payload.password),
        tenant_id=tenant.tenant_id,
        region=payload.region,
    )
    db.add(new_user)
    await db.commit()
    await db.refresh(new_user)

    return RegisterResponse(
        user_id=new_user.user_id,
        email=new_user.email,
        username=new_user.username,
        tenant_id=new_user.tenant_id,
        region=new_user.region,
        created_at=new_user.created_at,
    )


async def login_user(db: AsyncSession, payload: LoginRequest) -> LoginResponse:
    user = await db.scalar(select(User).where(User.email == payload.email.lower()))
    if not user or not _verify_password(payload.password, user.password_hash):
        raise InvalidCredentials("Invalid email or password.")

    return LoginResponse(
        access_token=_make_token(user),
        user_id=str(user.user_id),
        email=user.email,
        username=user.username,
    )
