# ⚡ Quick Start Guide

## 🎯 Start Entire Project in 3 Steps

### Step 1: Prepare
```bash
cd "c:\Users\meism\Desktop\Project integration"
```

### Step 2: Start All Services (Choose Your OS)

**Linux/Mac:**
```bash
chmod +x launcher.sh
./launcher.sh up --build
```

**Windows (PowerShell or CMD):**
```batch
launcher.bat up --build
```

### Step 3: Wait & Access

- ⏱️ **First run**: 2-3 minutes (building images)
- ⏱️ **Subsequent runs**: 30-60 seconds

Once ready, access:
- 🌐 **CloudPBL Frontend**: http://localhost:5173
- 🌐 **Files Upload**: http://localhost:5174
- 📚 **API Documentation**: http://localhost:8001/docs

## 📊 Check Status

```bash
# View running services
./launcher.sh ps

# Run health checks
./launcher.sh test

# View live logs
./launcher.sh logs
```

## 🛑 Stop Services

```bash
./launcher.sh down
```

## 🔍 View Logs

```bash
# All services
./launcher.sh logs

# Specific service
./launcher.sh logs user-module
./launcher.sh logs payment-module
./launcher.sh logs cloudpbl-backend
```

## 📋 Available Commands

```bash
./launcher.sh up              # Start all services
./launcher.sh up --build      # Rebuild and start
./launcher.sh down            # Stop all services
./launcher.sh restart         # Restart all services
./launcher.sh logs [service]  # View logs
./launcher.sh ps              # List containers
./launcher.sh test            # Health checks
./launcher.sh build           # Rebuild images
./launcher.sh clean           # Delete everything
./launcher.sh help            # Show help
```

## 🌐 Service URLs

| Service | URL |
|---------|-----|
| User Module | http://localhost:8001 |
| CloudPBL Backend | http://localhost:8002 |
| Payment Module | http://localhost:8003 |
| Restaurant Service | http://localhost:8004 |
| Payment Consumer | http://localhost:8005 |
| CloudPBL Frontend | http://localhost:5173 |
| Files Module | http://localhost:5174 |

## 💾 Database Access

**PostgreSQL**:
```bash
docker-compose exec postgres psql -U postgres
```

**MongoDB**:
```bash
docker-compose exec mongodb mongosh
```

**Redis**:
```bash
docker-compose exec redis redis-cli
```

## ⚙️ Configuration

Edit `.env` for configuration:

```env
# Security
SECRET_KEY=your-key
STRIPE_SECRET_KEY=sk_test_xxx

# Databases
POSTGRES_PASSWORD=postgres

# Environment
ENVIRONMENT=development
```

## 🐛 Troubleshooting

### Services won't start?
```bash
# Check Docker status
docker ps

# Check logs
./launcher.sh logs

# Restart everything
./launcher.sh restart
```

### Port already in use?
Edit `docker-compose.yml` and change port mappings.

### Out of memory?
Increase Docker memory in Docker Desktop settings (requires 8GB+).

### Clear everything and restart?
```bash
./launcher.sh clean
./launcher.sh up --build
```

## 📚 Full Documentation

See **README.md** for complete documentation and **INTEGRATION_SUMMARY.md** for integration details.

---

✅ **Ready to go!** Run `./launcher.sh up --build` now.
