#!/bin/bash

# ============================================
# DATABASE MIGRATION SCRIPT
# ============================================

set -e

echo "🔧 Running database migrations..."

# User Module - Alembic migrations
echo "→ Running User Module migrations..."
cd user_module-main/user_module-main
python -m alembic upgrade head
cd ../../

# Payment Module - SQLAlchemy init_db
echo "→ Initializing Payment Module database..."
python -c "from PaymentModule-main.PaymentModule-main.database.db import init_db; init_db()"

# Payment Success Consumer - SQLAlchemy init_db
echo "→ Initializing Payment Success Consumer database..."
cd payment-success-consumer-main/payment-success-consumer-main
python -c "from src.main import app; from src.config.settings import settings; from sqlalchemy import create_engine; engine = create_engine(settings.database_url); from src.models import *; Base.metadata.create_all(engine)"
cd ../../

echo "✓ All migrations completed successfully!"
