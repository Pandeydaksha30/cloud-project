#!/bin/bash

# ============================================
# WAIT FOR SERVICE SCRIPT
# Usage: ./wait-for-service.sh <service> <port>
# ============================================

SERVICE=$1
PORT=$2
TIMEOUT=${3:-30}

if [ -z "$SERVICE" ] || [ -z "$PORT" ]; then
    echo "Usage: ./wait-for-service.sh <service> <port> [timeout]"
    exit 1
fi

echo "⏳ Waiting for $SERVICE to be ready on port $PORT (timeout: ${TIMEOUT}s)..."

for i in $(seq 1 $TIMEOUT); do
    if nc -z "$SERVICE" "$PORT" 2>/dev/null; then
        echo "✓ $SERVICE is ready!"
        exit 0
    fi
    echo "  Attempt $i/$TIMEOUT... waiting..."
    sleep 1
done

echo "✗ $SERVICE did not become ready within ${TIMEOUT}s"
exit 1
