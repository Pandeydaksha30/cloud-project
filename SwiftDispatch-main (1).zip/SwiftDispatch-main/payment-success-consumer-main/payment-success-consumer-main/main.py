"""
Payment Success Consumer
Runs the FastAPI health API and optionally starts an embedded Celery worker.

Set RUN_CELERY_WORKER=true to embed the worker in this process (Render free tier).
Leave it unset (default false) when running the Celery worker as a separate container.
"""

import os
import subprocess
import sys
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware


@asynccontextmanager
async def lifespan(app: FastAPI):
    proc = None
    if os.getenv("RUN_CELERY_WORKER", "false").lower() == "true":
        proc = subprocess.Popen([
            sys.executable, "-m", "celery", "-A", "celery_app",
            "worker", "--loglevel=info", "--concurrency=2",
            "--without-heartbeat", "--without-gossip",
        ])
    yield
    if proc:
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()


app = FastAPI(
    title="Payment Success Consumer",
    description="Consumes payment success events and triggers dispatch",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health_check():
    return {"status": "healthy", "service": "payment-success-consumer"}


@app.get("/")
def root():
    return {
        "service": "payment-success-consumer",
        "status": "running",
        "description": "Consumes payment success events from Redis queue",
        "docs": "/docs",
        "redoc": "/redoc",
    }


@app.post("/webhook/payment-success")
def handle_payment_success(payload: dict):
    return {
        "status": "received",
        "message": "Payment success event queued for processing",
        "order_id": payload.get("order_id"),
    }
