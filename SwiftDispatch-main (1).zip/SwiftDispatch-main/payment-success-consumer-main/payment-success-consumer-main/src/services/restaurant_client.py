import httpx

from src.config.settings import settings
from src.models.event import PaymentSuccessEvent
from src.utils.logger import logger


class RestaurantClient:
    """HTTP adapter — calls the Restaurant Service to start order preparation."""

    def trigger_preparation(self, event: PaymentSuccessEvent):
        payload = {
            "idempotency_key": event.event_id,
            "order_id": event.order_id,
            "amount": event.amount,
            "currency": event.currency,
            "customer_name": event.customer_name,
            "restaurant_name": event.restaurant_name,
            "items": event.items,
        }
        try:
            resp = httpx.post(
                f"{settings.restaurant_api_url}/payment/webhook",
                json=payload,
                timeout=10.0,
            )
            resp.raise_for_status()
            logger.info(
                "Restaurant service triggered successfully",
                order_id=event.order_id,
                status_code=resp.status_code,
            )
        except httpx.HTTPStatusError as e:
            # 409 = duplicate (idempotency guard already fired) — treat as success
            if e.response.status_code == 409:
                logger.info("Restaurant: duplicate event ignored", order_id=event.order_id)
                return
            logger.error(
                "Restaurant service returned error",
                order_id=event.order_id,
                status_code=e.response.status_code,
                detail=e.response.text,
            )
            raise
        except httpx.RequestError as e:
            logger.error(
                "Restaurant service unreachable",
                order_id=event.order_id,
                error=str(e),
            )
            raise
