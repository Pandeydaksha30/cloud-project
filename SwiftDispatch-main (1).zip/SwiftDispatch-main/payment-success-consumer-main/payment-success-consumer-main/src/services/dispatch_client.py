import httpx

from src.config.settings import settings
from src.models.event import PaymentSuccessEvent
from src.utils.logger import logger


class DispatchClient:
    """HTTP adapter — calls the CloudPBL Dispatch Service to assign a rider."""

    def trigger_rider_assignment(self, event: PaymentSuccessEvent):
        payload = {
            "customer_name": event.customer_name or "Customer",
            "user_x": event.user_lat,
            "user_y": event.user_lng,
            "restaurant": event.restaurant_name or "Restaurant",
            "restaurant_x": event.restaurant_lat,
            "restaurant_y": event.restaurant_lng,
            "items": event.items,
            "amount": event.amount,
        }
        try:
            resp = httpx.post(
                f"{settings.dispatch_api_url}/api/order/place",
                json=payload,
                timeout=15.0,
            )
            resp.raise_for_status()
            data = resp.json()
            logger.info(
                "Dispatch service triggered successfully",
                order_id=event.order_id,
                dispatch_order_id=data.get("order_id"),
            )
        except httpx.HTTPStatusError as e:
            logger.error(
                "Dispatch service returned error",
                order_id=event.order_id,
                status_code=e.response.status_code,
                detail=e.response.text,
            )
            raise
        except httpx.RequestError as e:
            logger.error(
                "Dispatch service unreachable",
                order_id=event.order_id,
                error=str(e),
            )
            raise
