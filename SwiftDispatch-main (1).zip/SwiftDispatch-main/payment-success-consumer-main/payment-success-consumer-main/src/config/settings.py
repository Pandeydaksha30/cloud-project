from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    redis_url: str
    database_url: str
    celery_broker_url: str
    celery_result_backend: str

    # URLs for downstream services
    restaurant_api_url: str = "http://restaurant-service:8000"
    dispatch_api_url: str = "http://cloudpbl-backend:8000"

    environment: str = "development"
    log_level: str = "INFO"


settings = Settings()
