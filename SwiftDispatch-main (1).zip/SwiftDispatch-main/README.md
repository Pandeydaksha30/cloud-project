# 🚀 Project Integration - Food Delivery Microservices

Complete integrated food delivery platform with microservices architecture, event-driven design, and one-command deployment.

## 📋 Quick Start

### Prerequisites
- Docker Desktop (includes Docker & Docker Compose)
- Git
- 8GB RAM (minimum), 16GB recommended
- 20GB free disk space

### Installation & Launch

**Linux/Mac:**
```bash
# Make launcher executable
chmod +x launcher.sh

# Start everything with one command
./launcher.sh up --build

# View logs
./launcher.sh logs

# Stop services
./launcher.sh down
```

**Windows (PowerShell or CMD):**
```batch
# Start everything
launcher.bat up --build

# View logs
launcher.bat logs

# Stop services
launcher.bat down
```

## 🏗️ Architecture Overview

### 8 Integrated Services

#### Backend Services (FastAPI)
| Service | Port | Purpose | Database |
|---------|------|---------|----------|
| **User Module** | 8001 | Authentication & multi-tenant user management | PostgreSQL |
| **CloudPBL Backend** | 8002 | Order dispatch & real-time rider assignment | In-memory |
| **Payment Module** | 8003 | Stripe payment processing | PostgreSQL |
| **Restaurant Service** | 8004 | Order receiving, validation, retry logic | MongoDB |
| **Payment Success Consumer** | 8005 | Event consumer for payment events | PostgreSQL + Redis |

#### Frontend Services (React + Vite)
| Service | Port | Purpose |
|---------|------|---------|
| **CloudPBL Frontend** | 5173 | Real-time order tracking & rider maps |
| **Files Module** | 5174 | File upload & management |

#### Infrastructure Services
| Service | Port | Purpose |
|---------|------|---------|
| **PostgreSQL** | 5432 | Primary relational database |
| **MongoDB** | 27017 | Document store for orders & DLQ |
| **Redis** | 6379 | Message broker (Celery) & caching |

## 📊 Service Endpoints

Once started, access services at:

```
Backend APIs:
- User Module:              http://localhost:8001/docs
- CloudPBL Backend:         http://localhost:8002/docs
- Payment Module:           http://localhost:8003/docs
- Restaurant Service:       http://localhost:8004/docs
- Payment Consumer:         http://localhost:8005/docs

Frontends:
- CloudPBL Frontend:        http://localhost:5173
- Files Module:             http://localhost:5174

Infrastructure:
- PostgreSQL:               localhost:5432 (postgres:postgres)
- MongoDB:                  localhost:27017 (admin:admin)
- Redis:                    localhost:6379
```

## 📝 Commands Reference

### Start & Stop
```bash
./launcher.sh up              # Start all services
./launcher.sh up --build      # Rebuild and start
./launcher.sh down            # Stop all services
./launcher.sh restart         # Restart all services
```

### Monitoring
```bash
./launcher.sh ps              # List running containers
./launcher.sh logs            # Show all logs (live)
./launcher.sh logs user-module  # Show specific service logs
./launcher.sh test            # Run health checks
```

### Maintenance
```bash
./launcher.sh build           # Rebuild all images
./launcher.sh clean           # Delete containers & volumes (data loss!)
```

## 🔄 Complete Order Processing Flow

```
1. User places order via Frontend
   ↓
2. Payment Service processes (Stripe)
   ↓
3. PaymentSuccessEvent published to Redis queue
   ↓
4. Payment-Success-Consumer (Celery)
   ├─ Deduplicates on event_id (idempotency check)
   ├─ Triggers Restaurant Service (async)
   └─ Triggers CloudPBL Dispatch (async)
   ↓
5. Restaurant Service
   ├─ Receives webhook
   ├─ Validates (idempotency check)
   ├─ Saves to MongoDB
   └─ Enqueues to processing queue
   ↓
6. CloudPBL Dispatch
   ├─ Scores all available riders (distance algorithm)
   ├─ Attempts assignment (70% accept rate)
   ├─ Streams real-time updates via SSE
   └─ Updates UI with rider location
   ↓
7. Order complete - delivered to user
```

## 🔧 Configuration

### Environment Variables

Copy `.env.example` to `.env` and customize:

```env
# Security
SECRET_KEY=your-secret-key-here
STRIPE_SECRET_KEY=sk_test_your_key

# Databases
POSTGRES_USER=postgres
POSTGRES_PASSWORD=postgres

# Environment
ENVIRONMENT=development
LOG_LEVEL=INFO

# API
CORS_ORIGINS=http://localhost:5173,http://localhost:5174
```

## 📦 Dependencies & Standardization

### Python Services
- **FastAPI**: 0.111.0 (consistent across all services)
- **Uvicorn**: 0.30.1 (ASGI server)
- **Pydantic**: 2.7.1+ (validation)
- **SQLAlchemy**: 2.0.30 (async ORM)
- **Celery**: 5.6.3+ (async task queue with Redis)

### Node.js Services
- **Node**: 20-alpine
- **React**: 18.x
- **Vite**: 5.x
- **Leaflet**: Maps integration

### Infrastructure
- **Python**: 3.12-slim
- **PostgreSQL**: 16-alpine
- **MongoDB**: 7-alpine
- **Redis**: 7-alpine

**All conflicts resolved** ✓

## 📁 Project Structure

```
.
├── docker-compose.yml          ← Master orchestration
├── .env                        ← Configuration
├── launcher.sh / launcher.bat  ← One-command execution
├── init-scripts/               ← Database setup
│   ├── init-postgres.sql
│   └── init-mongodb.js
├── scripts/                    ← Utility scripts
│   ├── wait-for-service.sh
│   └── run-migrations.sh
│
├── cloudPBL-main/              ← Dispatch & rider assignment
│   ├── backend/                (FastAPI + asyncio)
│   └── frontend/               (React + Vite)
│
├── user_module-main/           ← User authentication
│   └── (FastAPI + PostgreSQL)
│
├── PaymentModule-main/         ← Stripe payments
│   └── (FastAPI + PostgreSQL)
│
├── Restaurant_service_project/ ← Order processing
│   └── (FastAPI + MongoDB)
│
├── payment-success-consumer/   ← Event consumer
│   └── (FastAPI + Celery + Redis)
│
└── files-main/                 ← File upload
    └── (React + Vite)
```

## 🔍 Troubleshooting

### Services won't start?
```bash
# Check Docker logs
docker-compose logs postgres    # Check database
docker-compose logs user-module # Check specific service

# Verify all dependencies
./launcher.sh ps
```

### Port conflicts?
If ports are already in use, modify `docker-compose.yml`:
```yaml
ports:
  - "8001:8000"  # Change 8001 to another available port
```

### Database issues?
```bash
# Clear all data
./launcher.sh clean

# Start fresh
./launcher.sh up
```

### Memory issues?
Docker needs ~6-8GB RAM. Increase Docker memory limits in Docker Desktop settings.

## 📊 Health Checks

All services have health endpoints:

```bash
# Check all services
./launcher.sh test

# Manual check
curl http://localhost:8001/health    # User Module
curl http://localhost:8002/health    # CloudPBL
curl http://localhost:8003/health    # Payment
curl http://localhost:8004/health    # Restaurant
curl http://localhost:8005/health    # Payment Consumer
```

## 🚀 Scaling

### Scale Celery Workers
```bash
# Run 3 Celery worker instances
docker-compose up -d --scale celery-worker=3
```

### Production Deployment

For production, update `docker-compose.yml`:

1. Remove `--reload` flags (development mode)
2. Change `ENVIRONMENT=development` to `production`
3. Use strong SECRET_KEY, STRIPE_SECRET_KEY
4. Enable SSL/TLS
5. Use managed databases (AWS RDS, MongoDB Atlas)
6. Use managed message broker (AWS SQS, Redis Cloud)
7. Deploy on Kubernetes (see `deployment/` folder)

## 📚 API Documentation

Each backend service provides OpenAPI documentation:

- User Module:      http://localhost:8001/docs
- CloudPBL:         http://localhost:8002/docs
- Payment:          http://localhost:8003/docs
- Restaurant:       http://localhost:8004/docs
- Payment Consumer: http://localhost:8005/docs

## 🔐 Security Notes

**Development Only:**
- All services use default credentials
- Debug mode enabled
- CORS open to localhost
- No HTTPS/TLS

**Before Production:**
- Change all SECRET_KEY values
- Disable debug mode
- Use strong database passwords
- Enable SSL/TLS
- Implement API authentication (OAuth2, JWT)
- Set strict CORS policies
- Rotate Stripe keys regularly

## 🐛 Debugging

### View Real-time Logs
```bash
# All services
./launcher.sh logs

# Specific service
./launcher.sh logs user-module
./launcher.sh logs celery-worker

# Follow format
docker-compose logs -f --tail=100 [service]
```

### Connect to Databases

**PostgreSQL:**
```bash
docker-compose exec postgres psql -U postgres
\l                    # List databases
\c dcc_userdb         # Connect to user database
\dt                   # List tables
```

**MongoDB:**
```bash
docker-compose exec mongodb mongosh
show databases
use order_system
db.orders.find()
```

**Redis:**
```bash
docker-compose exec redis redis-cli
KEYS *
GET key_name
```

## 🤝 Contributing

Before committing changes:

1. Ensure all services start without errors: `./launcher.sh up --build`
2. Run health checks: `./launcher.sh test`
3. Update `.env.example` if you add new variables
4. Document changes in relevant module READMEs

## 📄 License

This project is part of the educational platform demonstrating microservices patterns.

## 🎯 Project Statistics

- **8 Services**: Backend + Frontend + Infrastructure
- **3 Databases**: PostgreSQL, MongoDB, Redis
- **2 Frontend Apps**: React + Vite
- **4 FastAPI Backends**: Distributed services
- **1 Celery Queue**: Async task processing
- **1 Command to Deploy**: `./launcher.sh up --build`

## 📞 Support

For issues or questions:
1. Check logs: `./launcher.sh logs`
2. Run health checks: `./launcher.sh test`
3. Review individual module READMEs
4. Check Docker container status: `./launcher.sh ps`

---

**Last Updated:** May 2026  
**Status:** ✅ Production-Ready Framework (Development Defaults)
