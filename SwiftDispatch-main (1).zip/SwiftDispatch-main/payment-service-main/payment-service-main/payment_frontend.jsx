import React, { useState, useEffect, useCallback } from 'react';
import { AlertCircle, CheckCircle, Clock, RefreshCw, Zap, Wifi, WifiOff } from 'lucide-react';

const API_BASE_URL = 'http://localhost:8000/api/v1';

export default function PaymentService() {
  // Form state
  const [orderId, setOrderId] = useState('ORD-2024-001');
  const [userId, setUserId] = useState('USER-123');
  const [amount, setAmount] = useState(240);
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [idempotencyKey, setIdempotencyKey] = useState('');

  // Payment processing state
  const [loading, setLoading] = useState(false);
  const [paymentResponse, setPaymentResponse] = useState(null);
  const [error, setError] = useState(null);
  const [retryCount, setRetryCount] = useState(0);

  // System state
  const [metrics, setMetrics] = useState(null);
  const [circuitBreakerState, setCircuitBreakerState] = useState('CLOSED');
  const [events, setEvents] = useState([]);
  const [health, setHealth] = useState(null);

  // Generate idempotency key on mount
  useEffect(() => {
    generateIdempotencyKey();
  }, []);

  const generateIdempotencyKey = () => {
    const key = `payment_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    setIdempotencyKey(key);
  };

  const generateDuplicateKey = () => {
    // Keep the same key to test idempotency
    return idempotencyKey;
  };

  // Fetch metrics
  const fetchMetrics = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/metrics`);
      const data = await response.json();
      setMetrics(data);
      setCircuitBreakerState(data.circuit_breaker_state);
    } catch (err) {
      console.error('Failed to fetch metrics:', err);
    }
  };

  // Fetch events
  const fetchEvents = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/events`);
      const data = await response.json();
      setEvents(data.events);
    } catch (err) {
      console.error('Failed to fetch events:', err);
    }
  };

  // Fetch health
  const fetchHealth = async () => {
    try {
      const response = await fetch('http://localhost:8000/health');
      const data = await response.json();
      setHealth(data);
    } catch (err) {
      console.error('Failed to fetch health:', err);
      setHealth({ status: 'offline' });
    }
  };

  // Polling
  useEffect(() => {
    const interval = setInterval(() => {
      fetchMetrics();
      fetchEvents();
      fetchHealth();
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const handlePayment = async (useDuplicateKey = false) => {
    setLoading(true);
    setError(null);
    setPaymentResponse(null);

    const key = useDuplicateKey ? generateDuplicateKey() : idempotencyKey;

    const payload = {
      order_id: orderId,
      user_id: userId,
      amount: parseFloat(amount),
      currency: 'INR',
      idempotency_key: key,
      payment_method: paymentMethod,
      description: `Payment for order ${orderId}`,
    };

    try {
      const response = await fetch(`${API_BASE_URL}/payments`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      const data = await response.json();

      if (response.ok) {
        setPaymentResponse(data);
        setRetryCount(data.retry_count || 0);
      } else {
        setError(data.detail || 'Payment failed');
      }
    } catch (err) {
      setError(`Network error: ${err.message}`);
    } finally {
      setLoading(false);
      fetchMetrics();
      fetchEvents();
    }
  };

  const handleRefund = async () => {
    if (!paymentResponse || paymentResponse.status !== 'success') {
      setError('Can only refund successful payments');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(
        `${API_BASE_URL}/payments/${paymentResponse.transaction_id}/refund`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );

      const data = await response.json();
      setPaymentResponse(prev => ({
        ...prev,
        status: 'refunded',
        message: 'Payment has been refunded',
      }));
      setError(null);
    } catch (err) {
      setError(`Refund failed: ${err.message}`);
    } finally {
      setLoading(false);
      fetchMetrics();
      fetchEvents();
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'success':
        return 'text-green-600';
      case 'failed':
        return 'text-red-600';
      case 'processing':
        return 'text-yellow-600';
      default:
        return 'text-gray-600';
    }
  };

  const getCircuitBreakerColor = (state) => {
    switch (state) {
      case 'CLOSED':
        return 'bg-green-100 border-green-300';
      case 'OPEN':
        return 'bg-red-100 border-red-300';
      case 'HALF_OPEN':
        return 'bg-yellow-100 border-yellow-300';
      default:
        return 'bg-gray-100 border-gray-300';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Payment Service</h1>
          <p className="text-slate-400">Production-ready distributed payment system with idempotency & fault tolerance</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          {/* Left: Payment Form */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h2 className="text-2xl font-bold text-slate-800 mb-6">Process Payment</h2>

              <div className="space-y-4">
                {/* Order ID */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Order ID</label>
                  <input
                    type="text"
                    value={orderId}
                    onChange={(e) => setOrderId(e.target.value)}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    disabled={loading}
                  />
                </div>

                {/* User ID */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">User ID</label>
                  <input
                    type="text"
                    value={userId}
                    onChange={(e) => setUserId(e.target.value)}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    disabled={loading}
                  />
                </div>

                {/* Amount */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Amount (₹)</label>
                  <input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    disabled={loading}
                  />
                </div>

                {/* Payment Method */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Payment Method</label>
                  <select
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    disabled={loading}
                  >
                    <option value="card">Credit/Debit Card</option>
                    <option value="upi">UPI</option>
                    <option value="netbanking">Net Banking</option>
                    <option value="wallet">Digital Wallet</option>
                  </select>
                </div>

                {/* Idempotency Key */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Idempotency Key
                    <span className="text-red-600 font-bold ml-2">*CRITICAL*</span>
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={idempotencyKey}
                      readOnly
                      className="flex-1 px-4 py-2 border border-slate-300 rounded-lg bg-slate-50 font-mono text-sm"
                    />
                    <button
                      onClick={generateIdempotencyKey}
                      className="px-4 py-2 bg-slate-300 hover:bg-slate-400 text-slate-800 rounded-lg font-medium transition"
                      disabled={loading}
                    >
                      Generate New
                    </button>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    ℹ️ Unique per request. Same key = same response (prevents duplicate charges)
                  </p>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3 pt-4">
                  <button
                    onClick={() => handlePayment(false)}
                    disabled={loading}
                    className="flex-1 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 text-white font-bold py-3 rounded-lg transition flex items-center justify-center gap-2"
                  >
                    <Zap size={18} />
                    {loading ? 'Processing...' : 'Pay Now'}
                  </button>
                  <button
                    onClick={() => handlePayment(true)}
                    disabled={loading || !idempotencyKey}
                    title="Send duplicate request with same key - should return same response"
                    className="flex-1 bg-amber-600 hover:bg-amber-700 disabled:bg-amber-300 text-white font-bold py-3 rounded-lg transition flex items-center justify-center gap-2"
                  >
                    <RefreshCw size={18} />
                    Duplicate (Idempotency Test)
                  </button>
                </div>

                {/* Refund Button */}
                {paymentResponse?.status === 'success' && (
                  <button
                    onClick={handleRefund}
                    disabled={loading}
                    className="w-full bg-red-600 hover:bg-red-700 disabled:bg-red-300 text-white font-bold py-2 rounded-lg transition"
                  >
                    Refund Payment
                  </button>
                )}

                {/* Error Display */}
                {error && (
                  <div className="bg-red-50 border-l-4 border-red-400 p-4 flex gap-3">
                    <AlertCircle className="text-red-600 flex-shrink-0" size={20} />
                    <div>
                      <p className="font-bold text-red-800">Error</p>
                      <p className="text-red-700 text-sm">{error}</p>
                    </div>
                  </div>
                )}

                {/* Response Display */}
                {paymentResponse && (
                  <div className={`border-l-4 p-4 rounded ${paymentResponse.status === 'success' ? 'bg-green-50 border-green-400' : 'bg-red-50 border-red-400'}`}>
                    <div className="flex gap-3">
                      {paymentResponse.status === 'success' ? (
                        <CheckCircle className="text-green-600 flex-shrink-0" size={20} />
                      ) : (
                        <AlertCircle className="text-red-600 flex-shrink-0" size={20} />
                      )}
                      <div className="flex-1">
                        <p className={`font-bold ${getStatusColor(paymentResponse.status)}`}>
                          {paymentResponse.status.toUpperCase()}
                        </p>
                        <div className="text-sm text-slate-700 mt-2 space-y-1">
                          <p><strong>Transaction ID:</strong> {paymentResponse.transaction_id}</p>
                          <p><strong>Amount:</strong> ₹{paymentResponse.amount.toFixed(2)}</p>
                          <p><strong>Status:</strong> {paymentResponse.status}</p>
                          <p><strong>Message:</strong> {paymentResponse.message}</p>
                          <p><strong>Retries:</strong> {paymentResponse.retry_count}</p>
                          <p><strong>Timestamp:</strong> {new Date(paymentResponse.timestamp).toLocaleString()}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Right: System Status */}
          <div className="space-y-6">
            {/* Service Health */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <div className="flex items-center gap-2 mb-4">
                {health?.status === 'healthy' ? (
                  <Wifi className="text-green-600" size={20} />
                ) : (
                  <WifiOff className="text-red-600" size={20} />
                )}
                <h3 className="text-lg font-bold text-slate-800">Service Status</h3>
              </div>
              <div className="space-y-2 text-sm">
                <p className={`font-medium ${health?.status === 'healthy' ? 'text-green-600' : 'text-red-600'}`}>
                  {health?.status === 'healthy' ? '🟢 Online' : '🔴 Offline'}
                </p>
                <p className="text-slate-600">
                  Last Check: {health ? new Date(health.timestamp).toLocaleTimeString() : 'N/A'}
                </p>
              </div>
            </div>

            {/* Circuit Breaker */}
            <div className={`rounded-lg shadow-lg p-6 border-2 ${getCircuitBreakerColor(circuitBreakerState)}`}>
              <h3 className="text-lg font-bold text-slate-800 mb-4">Circuit Breaker</h3>
              <div className="space-y-2">
                <div>
                  <p className="text-xs text-slate-600 font-bold uppercase">State</p>
                  <p className="text-2xl font-bold text-slate-800">{circuitBreakerState}</p>
                </div>
                <div className="text-xs text-slate-600 mt-3">
                  <p><strong>CLOSED:</strong> Healthy</p>
                  <p><strong>OPEN:</strong> Failing (rejected)</p>
                  <p><strong>HALF_OPEN:</strong> Testing recovery</p>
                </div>
              </div>
            </div>

            {/* Metrics */}
            {metrics && (
              <div className="bg-white rounded-lg shadow-lg p-6">
                <h3 className="text-lg font-bold text-slate-800 mb-4">Metrics</h3>
                <div className="space-y-2 text-sm">
                  <p>📊 Total Requests: <strong>{metrics.metrics.total_requests}</strong></p>
                  <p>✅ Successful: <strong>{metrics.metrics.successful_payments}</strong></p>
                  <p>❌ Failed: <strong>{metrics.metrics.failed_payments}</strong></p>
                  <p>🔄 Retries: <strong>{metrics.metrics.retries}</strong></p>
                  <p>⏸️ Duplicates: <strong>{metrics.metrics.duplicate_requests}</strong></p>
                  <p>🚨 CB Trips: <strong>{metrics.metrics.circuit_breaker_trips}</strong></p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Events Log */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-2xl font-bold text-slate-800 mb-4">Event Stream (Async Communication)</h2>
          <div className="space-y-2 max-h-64 overflow-y-auto bg-slate-50 p-4 rounded font-mono text-xs">
            {events.length === 0 ? (
              <p className="text-slate-500">No events yet...</p>
            ) : (
              events.slice(-20).reverse().map((event, idx) => (
                <div key={idx} className="border-b border-slate-200 pb-2 mb-2">
                  <p className="text-slate-800">
                    <span className="font-bold text-blue-600">{event.event_type}</span>
                    {' '}| txn: <span className="text-orange-600">{event.transaction_id}</span>
                    {' '}| status: <span className="text-green-600">{event.status}</span>
                  </p>
                  <p className="text-slate-500 text-xs">{new Date(event.timestamp).toLocaleTimeString()}</p>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Documentation */}
        <div className="mt-8 bg-slate-700 rounded-lg shadow-lg p-6 text-white">
          <h3 className="text-xl font-bold mb-4">🏗️ Architecture & Patterns</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
            <div>
              <p className="font-bold text-blue-400 mb-2">✅ Idempotency</p>
              <p className="text-slate-300">Same idempotency_key = same response. Prevents duplicate charges.</p>
            </div>
            <div>
              <p className="font-bold text-blue-400 mb-2">🔄 Retry Logic</p>
              <p className="text-slate-300">Exponential backoff (1s, 2s, 4s). Handles transient failures.</p>
            </div>
            <div>
              <p className="font-bold text-blue-400 mb-2">⚡ Circuit Breaker</p>
              <p className="text-slate-300">Prevents cascading failures. Fails fast when gateway unhealthy.</p>
            </div>
            <div>
              <p className="font-bold text-blue-400 mb-2">📡 Event-Driven</p>
              <p className="text-slate-300">Async communication. Order Service consumes PaymentSuccess events.</p>
            </div>
            <div>
              <p className="font-bold text-blue-400 mb-2">🛡️ Fault Tolerance</p>
              <p className="text-slate-300">Graceful degradation. System survives individual component failures.</p>
            </div>
            <div>
              <p className="font-bold text-blue-400 mb-2">👁️ Observability</p>
              <p className="text-slate-300">Logs, metrics, traces. If you can't see it, you can't fix it.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
