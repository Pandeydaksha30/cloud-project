"""
Payment Service - Production-Ready Distributed System Implementation
Implements idempotency, fault tolerance, event-driven architecture, and observability
"""

from fastapi import FastAPI, HTTPException, Request, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Optional, Dict, List
import json
import logging
import uuid
from datetime import datetime, timedelta
from enum import Enum
import asyncio
import hashlib
from dataclasses import dataclass, asdict
import sqlite3
import os

# ============================================================================
# LOGGING & OBSERVABILITY
# ============================================================================
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - [%(levelname)s] - %(name)s - %(message)s'
)
logger = logging.getLogger("PaymentService")

class MetricsCollector:
    """Distributed systems observability - metrics collection"""
    def __init__(self):
        self.metrics = {
            "total_requests": 0,
            "successful_payments": 0,
            "failed_payments": 0,
            "duplicate_requests": 0,
            "retries": 0,
            "circuit_breaker_trips": 0,
        }
    
    def increment(self, metric_name: str):
        if metric_name in self.metrics:
            self.metrics[metric_name] += 1
            logger.info(f"METRIC: {metric_name} = {self.metrics[metric_name]}")
    
    def get_metrics(self) -> Dict:
        return self.metrics

metrics = MetricsCollector()

# ============================================================================
# DATA MODELS & ENUMS
# ============================================================================
class PaymentStatus(str, Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    SUCCESS = "success"
    FAILED = "failed"
    REFUNDED = "refunded"

class PaymentRequest(BaseModel):
    order_id: str = Field(..., description="Unique order identifier")
    user_id: str = Field(..., description="User ID making payment")
    amount: float = Field(..., gt=0, description="Payment amount in ₹")
    currency: str = "INR"
    idempotency_key: str = Field(..., description="CRITICAL: Unique ID for idempotent processing")
    payment_method: str = Field(default="card", description="card, upi, netbanking, wallet")
    card_token: Optional[str] = None
    description: Optional[str] = None

class PaymentResponse(BaseModel):
    transaction_id: str
    order_id: str
    status: PaymentStatus
    amount: float
    timestamp: str
    idempotency_key: str
    message: str
    retry_count: int = 0

class PaymentEvent(BaseModel):
    event_type: str
    transaction_id: str
    order_id: str
    status: PaymentStatus
    amount: float
    timestamp: str
    source: str = "PaymentService"

# ============================================================================
# IDEMPOTENCY STORE - PREVENTS DUPLICATE PROCESSING
# ============================================================================
class IdempotencyStore:
    """
    Database-backed idempotency store
    Key insight from workshop: "If your API cannot handle duplicate requests, it is not production-ready"
    """
    def __init__(self, db_path: str = "/tmp/payment_idempotency.db"):
        self.db_path = db_path
        self._init_db()
    
    def _init_db(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS idempotency_keys (
                idempotency_key TEXT PRIMARY KEY,
                transaction_id TEXT NOT NULL,
                status TEXT NOT NULL,
                response_json TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expires_at TIMESTAMP
            )
        ''')
        conn.commit()
        conn.close()
    
    def store_request(self, idempotency_key: str, transaction_id: str, 
                     status: str, response: dict, ttl_hours: int = 24):
        """Store idempotency key and response for future duplicates"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        expires_at = datetime.utcnow() + timedelta(hours=ttl_hours)
        
        try:
            cursor.execute('''
                INSERT OR REPLACE INTO idempotency_keys 
                (idempotency_key, transaction_id, status, response_json, expires_at)
                VALUES (?, ?, ?, ?, ?)
            ''', (idempotency_key, transaction_id, status, json.dumps(response), expires_at))
            conn.commit()
            logger.info(f"IDEMPOTENCY: Stored key={idempotency_key}, txn={transaction_id}")
        except Exception as e:
            logger.error(f"IDEMPOTENCY: Failed to store key - {str(e)}")
        finally:
            conn.close()
    
    def get_request(self, idempotency_key: str) -> Optional[Dict]:
        """Check if idempotency key already processed"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                SELECT transaction_id, status, response_json FROM idempotency_keys
                WHERE idempotency_key = ? AND expires_at > datetime('now')
            ''', (idempotency_key,))
            
            row = cursor.fetchone()
            if row:
                logger.info(f"IDEMPOTENCY: Cache hit for key={idempotency_key}")
                metrics.increment("duplicate_requests")
                return {
                    "transaction_id": row[0],
                    "status": row[1],
                    "response": json.loads(row[2])
                }
            return None
        except Exception as e:
            logger.error(f"IDEMPOTENCY: Failed to retrieve key - {str(e)}")
            return None
        finally:
            conn.close()

idempotency_store = IdempotencyStore()

# ============================================================================
# EVENT QUEUE - ASYNC EVENT-DRIVEN ARCHITECTURE
# ============================================================================
class EventQueue:
    """
    In-memory event queue for async communication
    In production: RabbitMQ, Kafka, AWS SQS, Google Cloud Pub/Sub
    """
    def __init__(self):
        self.events: List[PaymentEvent] = []
    
    def publish(self, event: PaymentEvent):
        """Publish event for other services to consume"""
        self.events.append(event)
        logger.info(f"EVENT: Published {event.event_type} | txn={event.transaction_id} | status={event.status}")
    
    def get_events(self) -> List[PaymentEvent]:
        """Simulate consuming events"""
        return self.events.copy()

event_queue = EventQueue()

# ============================================================================
# CIRCUIT BREAKER - FAULT TOLERANCE PATTERN
# ============================================================================
class CircuitBreaker:
    """
    Prevents cascading failures when external service (bank gateway) fails
    States: CLOSED (working) → OPEN (failing) → HALF_OPEN (testing)
    """
    def __init__(self, failure_threshold: int = 5, timeout_seconds: int = 60):
        self.failure_count = 0
        self.failure_threshold = failure_threshold
        self.timeout_seconds = timeout_seconds
        self.last_failure_time = None
        self.state = "CLOSED"  # CLOSED | OPEN | HALF_OPEN
    
    def record_success(self):
        self.failure_count = 0
        self.state = "CLOSED"
        logger.info("CIRCUIT_BREAKER: State → CLOSED (healthy)")
    
    def record_failure(self):
        self.failure_count += 1
        self.last_failure_time = datetime.utcnow()
        
        if self.failure_count >= self.failure_threshold:
            self.state = "OPEN"
            logger.warning("CIRCUIT_BREAKER: State → OPEN (too many failures, rejecting requests)")
            metrics.increment("circuit_breaker_trips")
        else:
            logger.warning(f"CIRCUIT_BREAKER: Failure #{self.failure_count}/{self.failure_threshold}")
    
    def can_attempt(self) -> bool:
        if self.state == "CLOSED":
            return True
        
        if self.state == "OPEN":
            elapsed = (datetime.utcnow() - self.last_failure_time).total_seconds()
            if elapsed > self.timeout_seconds:
                self.state = "HALF_OPEN"
                logger.info("CIRCUIT_BREAKER: State → HALF_OPEN (attempting recovery)")
                return True
            return False
        
        return True  # HALF_OPEN allows one attempt

payment_gateway_breaker = CircuitBreaker(failure_threshold=3, timeout_seconds=30)

# ============================================================================
# RETRY LOGIC WITH EXPONENTIAL BACKOFF
# ============================================================================
async def call_payment_gateway_with_retry(
    transaction_id: str,
    amount: float,
    idempotency_key: str,
    max_retries: int = 3
) -> Dict:
    """
    Call external payment gateway with exponential backoff and fault tolerance
    Implements: retries, circuit breaker, timeout, observability
    """
    
    for attempt in range(max_retries):
        try:
            if not payment_gateway_breaker.can_attempt():
                logger.error(f"GATEWAY: Circuit breaker OPEN, rejecting payment txn={transaction_id}")
                return {
                    "success": False,
                    "error": "Payment gateway unavailable (circuit breaker open)",
                    "retry_after_seconds": 30
                }
            
            # Simulate network call to bank gateway
            logger.info(f"GATEWAY: Attempting payment (attempt {attempt + 1}/{max_retries}) txn={transaction_id}")
            
            # Simulate failure 30% of the time (network chaos)
            import random
            if random.random() < 0.30:
                raise Exception("Bank gateway timeout (simulated)")
            
            # Success!
            payment_gateway_breaker.record_success()
            logger.info(f"GATEWAY: Payment processed successfully txn={transaction_id}")
            
            return {
                "success": True,
                "gateway_transaction_id": f"GW_{transaction_id}",
                "timestamp": datetime.utcnow().isoformat()
            }
        
        except Exception as e:
            metrics.increment("retries")
            payment_gateway_breaker.record_failure()
            
            if attempt < max_retries - 1:
                wait_time = 2 ** attempt  # Exponential backoff: 1s, 2s, 4s
                logger.warning(f"GATEWAY: Failed (attempt {attempt + 1}) - retrying in {wait_time}s | Error: {str(e)}")
                await asyncio.sleep(wait_time)
            else:
                logger.error(f"GATEWAY: All retries exhausted txn={transaction_id} | Error: {str(e)}")
                return {
                    "success": False,
                    "error": f"Payment gateway failed after {max_retries} retries: {str(e)}",
                    "final_error": True
                }
    
    return {"success": False, "error": "Unknown error in retry logic"}

# ============================================================================
# TRANSACTION STATE STORE
# ============================================================================
class TransactionStore:
    """In-memory transaction store (in production: Redis, DynamoDB, PostgreSQL)"""
    def __init__(self):
        self.transactions: Dict[str, Dict] = {}
    
    def create(self, transaction_id: str, order_id: str, amount: float, 
               idempotency_key: str) -> Dict:
        self.transactions[transaction_id] = {
            "transaction_id": transaction_id,
            "order_id": order_id,
            "amount": amount,
            "idempotency_key": idempotency_key,
            "status": PaymentStatus.PENDING,
            "created_at": datetime.utcnow().isoformat(),
            "updated_at": datetime.utcnow().isoformat(),
            "gateway_response": None,
            "error": None,
            "retry_count": 0
        }
        return self.transactions[transaction_id]
    
    def update_status(self, transaction_id: str, status: PaymentStatus, 
                     gateway_response: Optional[Dict] = None, error: Optional[str] = None):
        if transaction_id in self.transactions:
            self.transactions[transaction_id]["status"] = status
            self.transactions[transaction_id]["updated_at"] = datetime.utcnow().isoformat()
            self.transactions[transaction_id]["gateway_response"] = gateway_response
            self.transactions[transaction_id]["error"] = error
    
    def increment_retry(self, transaction_id: str):
        if transaction_id in self.transactions:
            self.transactions[transaction_id]["retry_count"] += 1
    
    def get(self, transaction_id: str) -> Optional[Dict]:
        return self.transactions.get(transaction_id)

transaction_store = TransactionStore()

# ============================================================================
# FASTAPI APPLICATION
# ============================================================================
app = FastAPI(
    title="Payment Service",
    description="Production-ready payment service with idempotency, fault tolerance, and event-driven architecture",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ============================================================================
# PAYMENT ENDPOINTS
# ============================================================================

@app.post("/api/v1/payments", response_model=PaymentResponse)
async def process_payment(payment_req: PaymentRequest, background_tasks: BackgroundTasks):
    """
    Process payment with idempotency guarantees
    
    CRITICAL: Client MUST provide idempotency_key
    If same request sent twice with same key → same response returned
    """
    metrics.increment("total_requests")
    
    logger.info(f"PAYMENT: Received request | order={payment_req.order_id} | idempotency_key={payment_req.idempotency_key}")
    
    # STEP 1: CHECK IDEMPOTENCY - PREVENT DUPLICATE PROCESSING
    cached = idempotency_store.get_request(payment_req.idempotency_key)
    if cached:
        logger.info(f"IDEMPOTENCY: Cache hit - returning previous response txn={cached['transaction_id']}")
        return PaymentResponse(
            transaction_id=cached["transaction_id"],
            order_id=payment_req.order_id,
            status=cached["response"]["status"],
            amount=payment_req.amount,
            timestamp=cached["response"]["timestamp"],
            idempotency_key=payment_req.idempotency_key,
            message=f"[IDEMPOTENT] Already processed with id {cached['transaction_id']}",
            retry_count=0
        )
    
    # STEP 2: CREATE TRANSACTION RECORD
    transaction_id = str(uuid.uuid4())[:8]
    transaction = transaction_store.create(
        transaction_id, 
        payment_req.order_id, 
        payment_req.amount,
        payment_req.idempotency_key
    )
    
    logger.info(f"TRANSACTION: Created | txn={transaction_id} | order={payment_req.order_id} | amount=₹{payment_req.amount}")
    
    # STEP 3: PROCESS PAYMENT WITH RETRY LOGIC
    transaction_store.update_status(transaction_id, PaymentStatus.PROCESSING)
    
    gateway_response = await call_payment_gateway_with_retry(
        transaction_id,
        payment_req.amount,
        payment_req.idempotency_key,
        max_retries=3
    )
    
    # STEP 4: HANDLE GATEWAY RESPONSE
    if gateway_response.get("success"):
        transaction_store.update_status(
            transaction_id, 
            PaymentStatus.SUCCESS,
            gateway_response=gateway_response
        )
        metrics.increment("successful_payments")
        
        # Publish event for Order Service to consume
        event = PaymentEvent(
            event_type="PaymentSuccess",
            transaction_id=transaction_id,
            order_id=payment_req.order_id,
            status=PaymentStatus.SUCCESS,
            amount=payment_req.amount,
            timestamp=datetime.utcnow().isoformat()
        )
        event_queue.publish(event)
        background_tasks.add_task(publish_event_to_queue, event)
        
        # Store in idempotency store
        response_dict = {
            "status": "success",
            "transaction_id": transaction_id,
            "timestamp": datetime.utcnow().isoformat()
        }
        idempotency_store.store_request(payment_req.idempotency_key, transaction_id, "success", response_dict)
        
        logger.info(f"SUCCESS: Payment successful | txn={transaction_id} | order={payment_req.order_id}")
        
        return PaymentResponse(
            transaction_id=transaction_id,
            order_id=payment_req.order_id,
            status=PaymentStatus.SUCCESS,
            amount=payment_req.amount,
            timestamp=datetime.utcnow().isoformat(),
            idempotency_key=payment_req.idempotency_key,
            message="Payment successful. Bank confirmed.",
            retry_count=transaction["retry_count"]
        )
    
    else:
        transaction_store.update_status(
            transaction_id,
            PaymentStatus.FAILED,
            error=gateway_response.get("error")
        )
        metrics.increment("failed_payments")
        
        # Publish failure event for compensation (refund)
        event = PaymentEvent(
            event_type="PaymentFailed",
            transaction_id=transaction_id,
            order_id=payment_req.order_id,
            status=PaymentStatus.FAILED,
            amount=payment_req.amount,
            timestamp=datetime.utcnow().isoformat()
        )
        event_queue.publish(event)
        background_tasks.add_task(publish_event_to_queue, event)
        
        logger.error(f"FAILED: Payment failed | txn={transaction_id} | error={gateway_response.get('error')}")
        
        return PaymentResponse(
            transaction_id=transaction_id,
            order_id=payment_req.order_id,
            status=PaymentStatus.FAILED,
            amount=payment_req.amount,
            timestamp=datetime.utcnow().isoformat(),
            idempotency_key=payment_req.idempotency_key,
            message=f"Payment failed: {gateway_response.get('error')}",
            retry_count=transaction["retry_count"]
        )

@app.get("/api/v1/payments/{transaction_id}")
async def get_payment_status(transaction_id: str):
    """Check payment status"""
    transaction = transaction_store.get(transaction_id)
    if not transaction:
        raise HTTPException(status_code=404, detail="Transaction not found")
    
    return transaction

@app.post("/api/v1/payments/{transaction_id}/refund")
async def refund_payment(transaction_id: str, background_tasks: BackgroundTasks):
    """
    Refund payment - forward recovery pattern
    In distributed systems: rollback isn't always possible, so design forward recovery
    """
    transaction = transaction_store.get(transaction_id)
    if not transaction:
        raise HTTPException(status_code=404, detail="Transaction not found")
    
    if transaction["status"] != PaymentStatus.SUCCESS:
        raise HTTPException(status_code=400, detail="Can only refund successful payments")
    
    logger.info(f"REFUND: Processing refund for txn={transaction_id}")
    
    transaction_store.update_status(transaction_id, PaymentStatus.REFUNDED)
    
    event = PaymentEvent(
        event_type="PaymentRefunded",
        transaction_id=transaction_id,
        order_id=transaction["order_id"],
        status=PaymentStatus.REFUNDED,
        amount=transaction["amount"],
        timestamp=datetime.utcnow().isoformat()
    )
    event_queue.publish(event)
    background_tasks.add_task(publish_event_to_queue, event)
    
    return {
        "transaction_id": transaction_id,
        "status": "refunded",
        "original_amount": transaction["amount"],
        "timestamp": datetime.utcnow().isoformat()
    }

@app.get("/api/v1/events")
async def get_events():
    """Get all published events (for other services to consume)"""
    return {
        "events": [asdict(e) for e in event_queue.get_events()],
        "count": len(event_queue.get_events())
    }

@app.get("/api/v1/metrics")
async def get_metrics():
    """Observability - metrics endpoint"""
    return {
        "service": "PaymentService",
        "timestamp": datetime.utcnow().isoformat(),
        "metrics": metrics.get_metrics(),
        "circuit_breaker_state": payment_gateway_breaker.state
    }

@app.get("/health")
async def health_check():
    """Health check for load balancers and orchestrators"""
    return {
        "status": "healthy",
        "service": "PaymentService",
        "timestamp": datetime.utcnow().isoformat(),
        "circuit_breaker": payment_gateway_breaker.state
    }

async def publish_event_to_queue(event: PaymentEvent):
    """Background task to publish event"""
    await asyncio.sleep(0.1)  # Simulate async publishing
    logger.info(f"PUBLISH: Event published to message queue | event_type={event.event_type}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
