from sqlalchemy import Column, Float, Integer, String, DateTime, Text
from sqlalchemy.orm import declarative_base
from datetime import datetime

Base = declarative_base()


class Transaction(Base):
    __tablename__ = "transactions"

    id = Column(Integer, primary_key=True, index=True)
    payment_intent_id = Column(String, unique=True, index=True)
    order_id = Column(String, index=True)
    amount = Column(Integer)        # stored in paise (smallest currency unit)
    currency = Column(String)
    customer_email = Column(String)
    status = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime)
    # Order metadata forwarded to downstream services
    customer_name = Column(String, nullable=True)
    restaurant_name = Column(String, nullable=True)
    items_json = Column(Text, nullable=True)    # JSON-encoded list of item strings
    user_lat = Column(Float, nullable=True)
    user_lng = Column(Float, nullable=True)
    restaurant_lat = Column(Float, nullable=True)
    restaurant_lng = Column(Float, nullable=True)
