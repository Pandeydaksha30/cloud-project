"""
PAYMENT MODULE - main.py
"""

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routes.payments import router as payments_router
from database.db import init_db


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield


app = FastAPI(
    title="Payment Module API",
    description="Handles payments for the food delivery system",
    version="1.0.0",
    lifespan=lifespan,
)

# Allow other modules (order module, rider module) to call this API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register payment routes
app.include_router(payments_router, prefix="/payments", tags=["Payments"])

@app.get("/health")
def health_check():
    """Health check endpoint for Docker container monitoring."""
    return {"status": "healthy", "service": "payment-module"}

@app.get("/")
def root():
    return {
        "message": "Payment Module is running!",
        "docs": "/docs",       # Auto-generated API docs
        "redoc": "/redoc"
    }
