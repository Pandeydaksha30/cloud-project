"""
PAYMENT MODULE - routes/payments.py

Endpoints:
  POST /payments/create     → Create a Stripe payment intent
  POST /payments/confirm    → Confirm / check payment status via Stripe
  GET  /payments/{id}       → Check payment status
  POST /payments/webhook    → Stripe webhook (signature-verified)
  POST /payments/simulate   → Dev-only: skip Stripe, publish event directly
  GET  /payments/           → List all payments
"""

import json
import os
import uuid
from datetime import datetime

import stripe
from celery import Celery
from dotenv import load_dotenv
from fastapi import APIRouter, Header, HTTPException, Request
from pydantic import BaseModel
from typing import List, Optional

from database.db import SessionLocal
from database import models
from database.models import Transaction

load_dotenv()

router = APIRouter()

stripe.api_key = os.getenv("STRIPE_SECRET_KEY")

_celery = Celery(broker=os.getenv("CELERY_BROKER_URL", "redis://localhost:6379"))


# ── Request schemas ───────────────────────────────────────────────────────────

class CreatePaymentRequest(BaseModel):
    order_id: str
    amount: int                     # paise (e.g. 36000 = ₹360)
    currency: str = "inr"
    customer_email: str
    customer_name: str = ""
    restaurant_name: str = ""
    items: List[str] = []
    user_lat: float = 28.57
    user_lng: float = 77.32
    restaurant_lat: float = 28.63
    restaurant_lng: float = 77.22


class ConfirmPaymentRequest(BaseModel):
    payment_intent_id: str


class SimulatePaymentRequest(BaseModel):
    order_id: str
    amount: int                     # paise
    currency: str = "inr"
    customer_email: str
    customer_name: str = ""
    restaurant_name: str = ""
    items: List[str] = []
    user_lat: float = 28.57
    user_lng: float = 77.32
    restaurant_lat: float = 28.63
    restaurant_lng: float = 77.22


# ── Helpers ───────────────────────────────────────────────────────────────────

def _publish_payment_event(transaction: Transaction):
    """Push a PaymentSuccessEvent to the Celery queue consumed by payment-success-consumer."""
    event = {
        "event_id": str(uuid.uuid4()),
        "order_id": transaction.order_id,
        "payment_id": transaction.payment_intent_id,
        "transaction_id": str(transaction.id),
        "amount": transaction.amount / 100,     # convert paise → rupees
        "currency": transaction.currency.upper(),
        "status": "SUCCESS",
        "timestamp": datetime.utcnow().isoformat(),
        "customer_name": transaction.customer_name or "",
        "restaurant_name": transaction.restaurant_name or "",
        "items": json.loads(transaction.items_json) if transaction.items_json else [],
        "user_lat": transaction.user_lat or 28.57,
        "user_lng": transaction.user_lng or 77.32,
        "restaurant_lat": transaction.restaurant_lat or 28.63,
        "restaurant_lng": transaction.restaurant_lng or 77.22,
    }
    _celery.send_task("consume_payment_success", args=[event])


def _update_transaction_status(payment_intent_id: str, status: str):
    db = SessionLocal()
    try:
        t = db.query(Transaction).filter(Transaction.payment_intent_id == payment_intent_id).first()
        if t:
            t.status = status
            t.updated_at = datetime.utcnow()
            db.commit()
            if status == "succeeded":
                _publish_payment_event(t)
    finally:
        db.close()


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.post("/create")
def create_payment(data: CreatePaymentRequest):
    if data.amount <= 0:
        raise HTTPException(status_code=400, detail="Amount must be greater than 0")

    try:
        intent = stripe.PaymentIntent.create(
            amount=data.amount,
            currency=data.currency,
            metadata={"order_id": data.order_id, "customer_email": data.customer_email},
        )
    except stripe.error.StripeError as e:
        raise HTTPException(status_code=400, detail=f"Stripe error: {str(e)}")

    db = SessionLocal()
    try:
        t = Transaction(
            payment_intent_id=intent.id,
            order_id=data.order_id,
            amount=data.amount,
            currency=data.currency,
            customer_email=data.customer_email,
            status="created",
            created_at=datetime.utcnow(),
            customer_name=data.customer_name,
            restaurant_name=data.restaurant_name,
            items_json=json.dumps(data.items),
            user_lat=data.user_lat,
            user_lng=data.user_lng,
            restaurant_lat=data.restaurant_lat,
            restaurant_lng=data.restaurant_lng,
        )
        db.add(t)
        db.commit()
    finally:
        db.close()
    return {
        "payment_intent_id": intent.id,
        "client_secret": intent.client_secret,
        "amount": data.amount,
        "currency": data.currency,
        "status": "created",
    }


@router.post("/confirm")
def confirm_payment(data: ConfirmPaymentRequest):
    try:
        intent = stripe.PaymentIntent.retrieve(data.payment_intent_id)
    except stripe.error.StripeError as e:
        raise HTTPException(status_code=400, detail=f"Stripe error: {str(e)}")

    db = SessionLocal()
    try:
        t = db.query(Transaction).filter(
            Transaction.payment_intent_id == data.payment_intent_id
        ).first()
        if not t:
            raise HTTPException(status_code=404, detail="Payment not found in database")
        t.status = intent.status
        t.updated_at = datetime.utcnow()
        db.commit()
        if intent.status == "succeeded":
            _publish_payment_event(t)
    finally:
        db.close()
    return {"payment_intent_id": intent.id, "status": intent.status}


@router.post("/simulate")
def simulate_payment(data: SimulatePaymentRequest):
    """
    Development endpoint: create a completed transaction and publish the
    PaymentSuccessEvent to Celery without touching Stripe.
    """
    fake_intent_id = f"pi_sim_{uuid.uuid4().hex}"
    db = SessionLocal()
    try:
        t = Transaction(
            payment_intent_id=fake_intent_id,
            order_id=data.order_id,
            amount=data.amount,
            currency=data.currency,
            customer_email=data.customer_email,
            status="succeeded",
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow(),
            customer_name=data.customer_name,
            restaurant_name=data.restaurant_name,
            items_json=json.dumps(data.items),
            user_lat=data.user_lat,
            user_lng=data.user_lng,
            restaurant_lat=data.restaurant_lat,
            restaurant_lng=data.restaurant_lng,
        )
        db.add(t)
        db.commit()
        _publish_payment_event(t)
    finally:
        db.close()
    return {
        "payment_intent_id": fake_intent_id,
        "order_id": data.order_id,
        "status": "succeeded",
        "message": "Simulated payment succeeded; event dispatched to Celery queue",
    }


@router.get("/{payment_intent_id}")
def get_payment_status(payment_intent_id: str):
    db = SessionLocal()
    try:
        t = db.query(Transaction).filter(Transaction.payment_intent_id == payment_intent_id).first()
    finally:
        db.close()
    if not t:
        raise HTTPException(status_code=404, detail="Payment not found")
    return {
        "payment_intent_id": t.payment_intent_id,
        "order_id": t.order_id,
        "amount": t.amount,
        "currency": t.currency,
        "status": t.status,
        "customer_email": t.customer_email,
        "created_at": t.created_at,
        "updated_at": t.updated_at,
    }


@router.post("/webhook")
async def stripe_webhook(request: Request, stripe_signature: str = Header(None)):
    payload = await request.body()
    try:
        event = stripe.Webhook.construct_event(
            payload, stripe_signature, os.getenv("STRIPE_WEBHOOK_SECRET")
        )
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid payload")
    except stripe.error.SignatureVerificationError:
        raise HTTPException(status_code=400, detail="Invalid signature")

    if event["type"] == "payment_intent.succeeded":
        _update_transaction_status(event["data"]["object"]["id"], "succeeded")
    elif event["type"] == "payment_intent.payment_failed":
        _update_transaction_status(event["data"]["object"]["id"], "failed")

    return {"status": "webhook received"}


@router.get("/")
def list_payments(limit: int = 20):
    db = SessionLocal()
    try:
        rows = (
            db.query(Transaction)
            .order_by(Transaction.created_at.desc())
            .limit(min(limit, 100))
            .all()
        )
    finally:
        db.close()
    return [
        {
            "payment_intent_id": t.payment_intent_id,
            "order_id": t.order_id,
            "amount": t.amount,
            "currency": t.currency,
            "status": t.status,
            "customer_email": t.customer_email,
            "created_at": t.created_at,
        }
        for t in rows
    ]
