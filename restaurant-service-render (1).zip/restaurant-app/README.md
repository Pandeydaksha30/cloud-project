# 🍽️ Restaurant Service — Integrated Backend

A unified food-delivery backend that integrates all project modules:
**User Auth · Payment Processing · Order Queue · Rider Dispatch**

**Tech Stack:** Python 3.11 · FastAPI · SQLite (via SQLAlchemy) · Uvicorn  
**Deploy to:** Render (single web service) · or run locally

---

## 📁 Project Structure

```
backend/
├── main.py                  # FastAPI app entry point
├── requirements.txt
├── static_frontend.html     # Built-in demo UI (served at /ui)
├── database/
│   ├── db.py                # SQLite engine + session setup
│   └── models.py            # All ORM tables (Users, Orders, Payments, Riders…)
├── routes/
│   ├── auth.py              # POST /auth/register, POST /auth/login
│   ├── payments.py          # POST /payments/create, /confirm, /history
│   ├── orders.py            # POST /orders/place, GET /orders/dlq
│   └── dispatch.py          # SSE dispatch stream, rider management
└── services/
    ├── queue.py             # In-memory SQS simulator
    └── order_processor.py   # Background worker (retry + DLQ logic)
render.yaml                  # One-click Render deployment config
```

---

## 🚀 Deploy to Render

### Option A — render.yaml (recommended)

1. Push this repo to GitHub.
2. In [Render Dashboard](https://render.com) → **New → Blueprint** → connect your GitHub repo.
3. Render auto-reads `render.yaml` and creates the web service + persistent disk.
4. Done — your service URL will be `https://<name>.onrender.com`.

### Option B — Manual Render setup

1. **New → Web Service** → connect your repo.
2. Set **Root Directory** to `backend`.
3. **Build Command:** `pip install -r requirements.txt`
4. **Start Command:** `uvicorn main:app --host 0.0.0.0 --port $PORT`
5. **Add Disk** (Disks tab): Name `restaurant-db`, Mount Path `/data`, Size `1 GB`.
6. **Environment Variables:**
   | Key | Value |
   |-----|-------|
   | `DATABASE_PATH` | `/data/restaurant.db` |
   | `PYTHON_VERSION` | `3.11.0` |
   | `STRIPE_SECRET_KEY` | *(optional) your Stripe key* |

---

## 💻 Run Locally

```bash
# 1 — Clone & enter backend dir
cd backend

# 2 — Create virtualenv (optional but recommended)
python -m venv venv && source venv/bin/activate   # Windows: venv\Scripts\activate

# 3 — Install dependencies
pip install -r requirements.txt

# 4 — Start server
uvicorn main:app --reload --port 8000
```

Open:
- **API docs:** http://localhost:8000/docs
- **Demo UI:** http://localhost:8000/ui
- **Health:** http://localhost:8000/health

---

## 🗺️ API Endpoints

### Auth — `/auth`
| Method | Path | Description |
|--------|------|-------------|
| POST | `/auth/register` | Register user (creates tenant if new) |
| POST | `/auth/login` | Login → returns bearer token |
| GET | `/auth/users` | List all users (admin/demo) |

### Orders — `/orders`
| Method | Path | Description |
|--------|------|-------------|
| POST | `/orders/place` | Place order (idempotent via `idempotency_key`) |
| GET | `/orders/` | List recent orders |
| GET | `/orders/{order_id}` | Get order status |
| GET | `/orders/dlq` | View dead-letter queue (failed orders) |

### Payments — `/payments`
| Method | Path | Description |
|--------|------|-------------|
| POST | `/payments/create` | Create payment intent (simulated or Stripe) |
| POST | `/payments/confirm` | Confirm / mark as succeeded |
| GET | `/payments/history` | List recent transactions |
| GET | `/payments/{id}` | Get payment status |
| POST | `/payments/webhook` | Webhook receiver |

### Dispatch — `/dispatch`
| Method | Path | Description |
|--------|------|-------------|
| POST | `/dispatch/order` | Dispatch order — returns SSE stream |
| GET | `/dispatch/riders` | List riders + status |
| POST | `/dispatch/riders/seed` | Seed 5 demo riders |
| POST | `/dispatch/reset` | Reset all riders to idle |

---

## ⚙️ Distributed Systems Concepts

| Concept | Implementation |
|---------|---------------|
| **Idempotency** | `idempotency_key` on orders (in-memory cache + DB unique constraint) |
| **Message Queue** | In-memory `Queue` (SQS simulator) in `services/queue.py` |
| **Background Worker** | Daemon thread consuming the queue in `order_processor.py` |
| **Retry + Backoff** | Up to 3 retries before sending to DLQ |
| **Dead Letter Queue** | `dead_letter_queue` SQLite table |
| **Circuit Breaker** | Rider timeout + fallback to next rider in dispatch |
| **SSE Streaming** | Real-time dispatch events via `StreamingResponse` |
| **Load Balancing** | Rider scoring function (distance + rating) |
| **CORS** | Enabled for all origins (tighten in production) |

---

## 🔐 Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `DATABASE_PATH` | `./restaurant.db` | Path to SQLite file |
| `STRIPE_SECRET_KEY` | *(unset)* | If set, enables real Stripe payments |
| `STRIPE_WEBHOOK_SECRET` | *(unset)* | Stripe webhook signature key |

---

## 🔄 Switching to a Production Database

SQLite is great for demos. To upgrade to PostgreSQL on Render:

1. Create a Render **PostgreSQL** managed database.
2. Copy the **Internal Database URL**.
3. Install: `pip install psycopg2-binary`
4. Change `DATABASE_URL` in `database/db.py` to use the PostgreSQL URL.
5. Remove `connect_args={"check_same_thread": False}` (SQLite-only).

---

## 📝 Notes

- The SQLite file persists on Render via the `/data` persistent disk.
- The first deploy auto-creates all tables on startup (`init_db()`).
- Rider seeding (`POST /dispatch/riders/seed`) is idempotent — safe to call multiple times.
- Payment intents are **simulated** unless `STRIPE_SECRET_KEY` is configured.
