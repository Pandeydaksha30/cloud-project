"""
Restaurant Service — Integrated Backend
Combines: User Auth, Payment, Dispatch, Order Queue
Tech Stack: Python + FastAPI + SQLite (SQLAlchemy)
Deploy: Render (single web service)
"""

import asyncio
import json
import logging
import os
import sys
import threading
import time
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timezone

from fastapi import FastAPI, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.exceptions import RequestValidationError

# ── Local imports ──────────────────────────────────────────────────────────────
from database.db import init_db, engine, Base
from routes.auth import router as auth_router
from routes.payments import router as payments_router
from routes.orders import router as orders_router
from routes.dispatch import router as dispatch_router
from services.order_processor import start_order_worker

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s %(message)s",
)
logger = logging.getLogger("main")


# ── Lifespan ───────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Create all SQLite tables
    init_db()
    logger.info("✅ SQLite database initialised")

    # Start background order-processing worker thread
    t = threading.Thread(target=start_order_worker, daemon=True)
    t.start()
    logger.info("✅ Order worker thread started")

    yield
    logger.info("Shutting down…")


# ── App ────────────────────────────────────────────────────────────────────────

app = FastAPI(
    title="Restaurant Service API",
    description="Integrated food-delivery backend — User Auth · Payments · Dispatch",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routers ────────────────────────────────────────────────────────────────────

app.include_router(auth_router,     prefix="/auth",     tags=["Auth"])
app.include_router(payments_router, prefix="/payments", tags=["Payments"])
app.include_router(orders_router,   prefix="/orders",   tags=["Orders"])
app.include_router(dispatch_router, prefix="/dispatch", tags=["Dispatch"])


# ── Root / Health ──────────────────────────────────────────────────────────────

@app.get("/")
def root():
    return {
        "service": "Restaurant Service",
        "status": "running",
        "docs": "/docs",
        "redoc": "/redoc",
        "modules": ["auth", "payments", "orders", "dispatch"],
    }


@app.get("/health")
def health():
    return {"status": "ok", "timestamp": datetime.utcnow().isoformat()}


@app.get("/ui", response_class=HTMLResponse)
def frontend():
    """Serve the built-in demo UI."""
    import pathlib
    html_path = pathlib.Path(__file__).parent / "static_frontend.html"
    return HTMLResponse(html_path.read_text())


# ── Validation error override ──────────────────────────────────────────────────

@app.exception_handler(RequestValidationError)
async def validation_error_handler(request: Request, exc: RequestValidationError):
    first = exc.errors()[0]
    field = ".".join(str(loc) for loc in first["loc"] if loc != "body")
    msg   = first["msg"]
    code  = "WEAK_PASSWORD" if "Password" in msg else "VALIDATION_ERROR"
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={"error": {"code": code, "message": msg, "field": field or None}},
    )
