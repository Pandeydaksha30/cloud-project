"""
database/db.py
SQLite database setup using SQLAlchemy (sync).
On Render the DB file is stored at /data/restaurant.db (persistent disk)
or falls back to ./restaurant.db locally.
"""

import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase

# ── Resolve DB path ────────────────────────────────────────────────────────────
# Render persistent disk is mounted at /data — use it when available.
_RENDER_DATA = "/data"
if os.path.isdir(_RENDER_DATA):
    DB_PATH = os.path.join(_RENDER_DATA, "restaurant.db")
else:
    DB_PATH = os.getenv("DATABASE_PATH", "./restaurant.db")

DATABASE_URL = f"sqlite:///{DB_PATH}"

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False},  # Required for SQLite in multi-threaded apps
    echo=False,
)

SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)


class Base(DeclarativeBase):
    pass


def init_db():
    """Create all tables defined in models (called once at startup)."""
    # Import models so their metadata is registered
    import database.models  # noqa: F401
    Base.metadata.create_all(bind=engine)


def get_db():
    """Dependency-injection helper — yields a DB session and closes it after."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
