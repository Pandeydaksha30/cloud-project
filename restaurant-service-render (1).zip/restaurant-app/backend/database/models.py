"""
database/models.py
All SQLAlchemy ORM models for the integrated restaurant service.
Uses SQLite-compatible column types (no PostgreSQL UUID — plain String instead).
"""

import uuid
from datetime import datetime

from sqlalchemy import (
    Boolean, Column, DateTime, Float, ForeignKey,
    Integer, String, Text, JSON
)
from database.db import Base


def _uuid() -> str:
    return str(uuid.uuid4())


# ── Tenant ─────────────────────────────────────────────────────────────────────

class Tenant(Base):
    __tablename__ = "tenants"

    tenant_id  = Column(String(36), primary_key=True, default=_uuid)
    name       = Column(String(100), nullable=False)
    plan       = Column(String(30), default="free")
    created_at = Column(DateTime, default=datetime.utcnow)


# ── User ───────────────────────────────────────────────────────────────────────

class User(Base):
    __tablename__ = "users"

    user_id       = Column(String(36), primary_key=True, default=_uuid)
    email         = Column(String(255), unique=True, nullable=False, index=True)
    username      = Column(String(100), unique=True, nullable=False, index=True)
    password_hash = Column(Text, nullable=False)
    tenant_id     = Column(String(36), ForeignKey("tenants.tenant_id"), nullable=False)
    region        = Column(String(50), default="ap-south-1")
    status        = Column(String(20), default="active")
    mfa_enabled   = Column(Boolean, default=False)
    last_login    = Column(DateTime, nullable=True)
    created_at    = Column(DateTime, default=datetime.utcnow)
    updated_at    = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


# ── Payment Transaction ────────────────────────────────────────────────────────

class Transaction(Base):
    __tablename__ = "transactions"

    id                 = Column(Integer, primary_key=True, autoincrement=True)
    payment_intent_id  = Column(String(100), unique=True, index=True)
    order_id           = Column(String(100), nullable=False)
    amount             = Column(Integer, nullable=False)   # paise / smallest currency unit
    currency           = Column(String(10), default="inr")
    customer_email     = Column(String(255))
    status             = Column(String(30), default="created")
    created_at         = Column(DateTime, default=datetime.utcnow)
    updated_at         = Column(DateTime, nullable=True)


# ── Restaurant Order ───────────────────────────────────────────────────────────

class Order(Base):
    __tablename__ = "orders"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    order_id        = Column(String(100), unique=True, index=True, default=lambda: f"ORD-{uuid.uuid4().hex[:6].upper()}")
    idempotency_key = Column(String(200), unique=True, index=True)
    customer_name   = Column(String(200))
    customer_email  = Column(String(255))
    restaurant      = Column(String(200))
    items           = Column(Text)   # JSON-encoded list
    amount          = Column(Float, nullable=False)
    status          = Column(String(30), default="PLACED")   # PLACED | PROCESSING | DELIVERED | FAILED
    retry_count     = Column(Integer, default=0)
    created_at      = Column(DateTime, default=datetime.utcnow)
    updated_at      = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


# ── Dead-Letter Queue ──────────────────────────────────────────────────────────

class DeadLetterEntry(Base):
    __tablename__ = "dead_letter_queue"

    id         = Column(Integer, primary_key=True, autoincrement=True)
    order_id   = Column(String(100))
    payload    = Column(Text)   # JSON-encoded order dict
    reason     = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)


# ── Rider ─────────────────────────────────────────────────────────────────────

class RiderRecord(Base):
    __tablename__ = "riders"

    id          = Column(String(36), primary_key=True, default=_uuid)
    name        = Column(String(100))
    phone       = Column(String(20))
    x           = Column(Float, default=5.0)
    y           = Column(Float, default=5.0)
    status      = Column(String(20), default="idle")   # idle | busy | offline
    rating      = Column(Float, default=4.5)
    updated_at  = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
