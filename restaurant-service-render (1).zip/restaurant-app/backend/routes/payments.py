"""
routes/payments.py
Payment processing endpoints.
Uses simulated payment intents (no Stripe dependency required for demo).
Set STRIPE_SECRET_KEY env var to enable real Stripe integration.
"""

import os
import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from database.db import get_db
from database.models import Transaction

router = APIRouter()

# Optional Stripe integration
_STRIPE_KEY = os.getenv("STRIPE_SECRET_KEY")
_stripe = None
if _STRIPE_KEY:
    try:
        import stripe
        stripe.api_key = _STRIPE_KEY
        _stripe = stripe
    except ImportError:
        pass


# ── Schemas ────────────────────────────────────────────────────────────────────

class CreatePaymentRequest(BaseModel):
    order_id:       str
    amount:         int        # In paise (100 paise = ₹1)
    currency:       str = "inr"
    customer_email: str


class ConfirmPaymentRequest(BaseModel):
    payment_intent_id: str


# ── Helpers ────────────────────────────────────────────────────────────────────

def _simulated_intent_id() -> str:
    return f"pi_sim_{uuid.uuid4().hex[:20]}"


def _create_simulated_intent(data: CreatePaymentRequest) -> dict:
    """Simulate a Stripe-like payment intent without calling Stripe."""
    return {
        "id":            _simulated_intent_id(),
        "client_secret": f"pi_sim_secret_{uuid.uuid4().hex[:16]}",
        "amount":        data.amount,
        "currency":      data.currency,
        "status":        "requires_payment_method",
    }


# ── Endpoints ──────────────────────────────────────────────────────────────────

@router.post("/create")
def create_payment(data: CreatePaymentRequest, db: Session = Depends(get_db)):
    """Create a payment intent (simulated or real Stripe)."""
    if data.amount <= 0:
        raise HTTPException(status_code=400, detail="Amount must be greater than 0")

    if _stripe:
        try:
            intent = _stripe.PaymentIntent.create(
                amount=data.amount,
                currency=data.currency,
                metadata={"order_id": data.order_id, "customer_email": data.customer_email},
            )
            intent_id     = intent.id
            client_secret = intent.client_secret
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Stripe error: {str(e)}")
    else:
        sim = _create_simulated_intent(data)
        intent_id     = sim["id"]
        client_secret = sim["client_secret"]

    txn = Transaction(
        payment_intent_id = intent_id,
        order_id          = data.order_id,
        amount            = data.amount,
        currency          = data.currency,
        customer_email    = data.customer_email,
        status            = "created",
    )
    db.add(txn)
    db.commit()
    db.refresh(txn)

    return {
        "payment_intent_id": intent_id,
        "client_secret":     client_secret,
        "amount":            data.amount,
        "currency":          data.currency,
        "status":            "created",
        "mode":              "stripe" if _stripe else "simulated",
    }


@router.post("/confirm")
def confirm_payment(data: ConfirmPaymentRequest, db: Session = Depends(get_db)):
    """Confirm / mark a payment as succeeded (simulated)."""
    txn = db.query(Transaction).filter(
        Transaction.payment_intent_id == data.payment_intent_id
    ).first()
    if not txn:
        raise HTTPException(status_code=404, detail="Payment not found")

    txn.status     = "succeeded"
    txn.updated_at = datetime.utcnow()
    db.commit()

    return {
        "payment_intent_id": txn.payment_intent_id,
        "order_id":          txn.order_id,
        "status":            txn.status,
        "amount":            txn.amount,
        "currency":          txn.currency,
    }


@router.post("/webhook")
async def payment_webhook(request: dict, db: Session = Depends(get_db)):
    """
    Webhook endpoint.
    In production Stripe calls this — here we accept manual POST for testing.
    Body: {"payment_intent_id": "...", "status": "succeeded|failed"}
    """
    pid    = request.get("payment_intent_id")
    new_st = request.get("status", "succeeded")

    txn = db.query(Transaction).filter(Transaction.payment_intent_id == pid).first()
    if txn:
        txn.status     = new_st
        txn.updated_at = datetime.utcnow()
        db.commit()

    return {"status": "webhook received"}


@router.get("/history")
def list_payments(limit: int = 20, db: Session = Depends(get_db)):
    """List recent transactions."""
    txns = db.query(Transaction).order_by(Transaction.created_at.desc()).limit(limit).all()
    return [
        {
            "payment_intent_id": t.payment_intent_id,
            "order_id":          t.order_id,
            "amount":            t.amount,
            "currency":          t.currency,
            "status":            t.status,
            "customer_email":    t.customer_email,
            "created_at":        t.created_at.isoformat() if t.created_at else None,
        }
        for t in txns
    ]


@router.get("/{payment_intent_id}")
def get_payment(payment_intent_id: str, db: Session = Depends(get_db)):
    txn = db.query(Transaction).filter(
        Transaction.payment_intent_id == payment_intent_id
    ).first()
    if not txn:
        raise HTTPException(status_code=404, detail="Payment not found")
    return {
        "payment_intent_id": txn.payment_intent_id,
        "order_id":          txn.order_id,
        "amount":            txn.amount,
        "currency":          txn.currency,
        "status":            txn.status,
        "customer_email":    txn.customer_email,
        "created_at":        txn.created_at.isoformat() if txn.created_at else None,
    }
