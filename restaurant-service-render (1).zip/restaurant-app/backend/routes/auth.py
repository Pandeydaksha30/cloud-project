"""
routes/auth.py
User registration and login endpoints.
Password hashing via hashlib (stdlib — no bcrypt version issues).
JWT-less for simplicity — returns a session token for demo.
"""

import hashlib
import secrets
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, EmailStr, field_validator
from sqlalchemy.orm import Session

from database.db import get_db
from database.models import User, Tenant

router = APIRouter()


# ── Password helpers ───────────────────────────────────────────────────────────

def _hash_password(password: str) -> str:
    salt = secrets.token_hex(16)
    h = hashlib.sha256((salt + password).encode()).hexdigest()
    return f"{salt}${h}"


def _verify_password(password: str, stored: str) -> bool:
    try:
        salt, h = stored.split("$", 1)
        return hashlib.sha256((salt + password).encode()).hexdigest() == h
    except Exception:
        return False


# ── Schemas ────────────────────────────────────────────────────────────────────

class RegisterRequest(BaseModel):
    email:       EmailStr
    username:    str
    password:    str
    tenant_name: str = "default"

    @field_validator("password")
    @classmethod
    def strong_password(cls, v):
        if len(v) < 8:
            raise ValueError("Password must be at least 8 characters")
        return v


class LoginRequest(BaseModel):
    email:    EmailStr
    password: str


# ── Helpers ────────────────────────────────────────────────────────────────────

def _get_or_create_tenant(db: Session, name: str) -> Tenant:
    tenant = db.query(Tenant).filter(Tenant.name == name).first()
    if not tenant:
        tenant = Tenant(name=name)
        db.add(tenant)
        db.commit()
        db.refresh(tenant)
    return tenant


# ── Endpoints ──────────────────────────────────────────────────────────────────

@router.post("/register", status_code=status.HTTP_201_CREATED)
def register(payload: RegisterRequest, db: Session = Depends(get_db)):
    """Register a new user. Creates tenant if it doesn't exist."""

    if db.query(User).filter(User.email == payload.email).first():
        raise HTTPException(status_code=409, detail={"code": "EMAIL_ALREADY_EXISTS",
                                                      "message": "Email is already registered"})
    if db.query(User).filter(User.username == payload.username).first():
        raise HTTPException(status_code=409, detail={"code": "USERNAME_TAKEN",
                                                      "message": "Username is already taken"})

    tenant = _get_or_create_tenant(db, payload.tenant_name)

    user = User(
        email         = payload.email,
        username      = payload.username,
        password_hash = _hash_password(payload.password),
        tenant_id     = tenant.tenant_id,
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    return {
        "user_id":    user.user_id,
        "email":      user.email,
        "username":   user.username,
        "tenant_id":  user.tenant_id,
        "status":     user.status,
        "created_at": user.created_at.isoformat(),
    }


@router.post("/login")
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    """Login — returns a simple bearer token (UUID) for demo purposes."""

    user = db.query(User).filter(User.email == payload.email).first()
    if not user or not _verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=401, detail={"code": "INVALID_CREDENTIALS",
                                                      "message": "Email or password incorrect"})

    user.last_login = datetime.utcnow()
    db.commit()

    token = str(uuid.uuid4())
    return {
        "access_token": token,
        "token_type":   "bearer",
        "user_id":      user.user_id,
        "email":        user.email,
        "username":     user.username,
    }


@router.get("/users")
def list_users(db: Session = Depends(get_db)):
    """List all users (admin / demo use)."""
    users = db.query(User).all()
    return [{"user_id": u.user_id, "email": u.email,
             "username": u.username, "status": u.status,
             "created_at": u.created_at.isoformat()} for u in users]
