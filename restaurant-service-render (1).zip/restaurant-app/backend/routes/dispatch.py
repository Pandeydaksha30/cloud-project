"""
routes/dispatch.py
Rider dispatch endpoints with Server-Sent Events (SSE) streaming.
Ported from cloudPBL — uses SQLite-backed riders instead of in-memory only.
"""

import asyncio
import json
import logging
import math
import random
import time
from typing import AsyncGenerator

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session

from database.db import get_db
from database.models import RiderRecord

router  = APIRouter()
logger  = logging.getLogger("dispatch")

MAX_RETRIES    = 3
RIDER_TIMEOUT  = 3.0   # seconds


# ── Schemas ────────────────────────────────────────────────────────────────────

class DispatchRequest(BaseModel):
    order_id:      str
    customer_name: str
    user_x:        float = 5.0
    user_y:        float = 5.0
    restaurant:    str   = "Pizza Palace"
    restaurant_x:  float = 3.0
    restaurant_y:  float = 3.0
    items:         list[str] = []
    amount:        float     = 0.0


# ── Scoring ────────────────────────────────────────────────────────────────────

def _distance(x1, y1, x2, y2) -> float:
    return math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2)


def _score(rider: RiderRecord, ux, uy, rx, ry) -> float:
    """Lower score = better candidate."""
    dist_to_user = _distance(rider.x, rider.y, ux, uy)
    dist_to_rest = _distance(rider.x, rider.y, rx, ry)
    rating_bonus = (5.0 - rider.rating) * 0.5
    return dist_to_user + dist_to_rest * 0.5 + rating_bonus


# ── Core dispatch coroutine (streams events) ───────────────────────────────────

async def _do_dispatch(order: DispatchRequest, db: Session) -> AsyncGenerator[str, None]:
    """Async generator — yields SSE data lines."""

    def _sse(event: dict) -> str:
        return f"data: {json.dumps(event)}\n\n"

    yield _sse({"type": "started", "order_id": order.order_id,
                "msg": f"Dispatching order {order.order_id}…"})

    idle_riders = db.query(RiderRecord).filter(RiderRecord.status == "idle").all()

    if not idle_riders:
        yield _sse({"type": "order_failed", "order_id": order.order_id,
                    "msg": "No riders available"})
        return

    ranked = sorted(idle_riders, key=lambda r: _score(r, order.user_x, order.user_y,
                                                       order.restaurant_x, order.restaurant_y))

    yield _sse({"type": "riders_ranked",
                "riders": [{"id": r.id, "name": r.name,
                             "score": round(_score(r, order.user_x, order.user_y,
                                                   order.restaurant_x, order.restaurant_y), 2)}
                            for r in ranked]})

    for rider in ranked:
        yield _sse({"type": "contacting_rider", "rider_id": rider.id,
                    "rider_name": rider.name,
                    "msg": f"Contacting {rider.name}…"})

        # Simulate network latency + rider decision
        await asyncio.sleep(random.uniform(0.5, 1.5))

        accepted = random.random() < 0.65   # 65 % acceptance rate

        if accepted:
            # Mark rider as busy
            rider.status = "busy"
            db.commit()

            yield _sse({"type": "rider_assigned",
                        "rider_id":   rider.id,
                        "rider_name": rider.name,
                        "order_id":   order.order_id,
                        "msg": f"🛵 {rider.name} accepted and is on the way!"})
            yield _sse({"type": "done"})
            return
        else:
            reason = random.choice(["busy", "timeout", "rejected"])
            yield _sse({"type": "rider_rejected", "rider_id": rider.id,
                        "rider_name": rider.name, "reason": reason,
                        "msg": f"{rider.name} {reason} — trying next rider…"})

    yield _sse({"type": "order_failed", "order_id": order.order_id,
                "msg": "All riders rejected. Order moved to DLQ."})
    yield _sse({"type": "done"})


# ── Endpoints ──────────────────────────────────────────────────────────────────

@router.post("/order")
async def dispatch_order(req: DispatchRequest, db: Session = Depends(get_db)):
    """Stream dispatch events as Server-Sent Events."""

    async def generator():
        async for chunk in _do_dispatch(req, db):
            yield chunk

    return StreamingResponse(
        generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@router.get("/riders")
def get_riders(db: Session = Depends(get_db)):
    """List all riders and their current status."""
    riders = db.query(RiderRecord).all()
    return {
        "riders": [
            {"id": r.id, "name": r.name, "phone": r.phone,
             "x": r.x, "y": r.y, "status": r.status, "rating": r.rating}
            for r in riders
        ]
    }


@router.post("/riders/seed")
def seed_riders(db: Session = Depends(get_db)):
    """Seed 5 demo riders (idempotent — skips if riders already exist)."""
    if db.query(RiderRecord).count() > 0:
        return {"msg": "Riders already seeded"}

    names = ["Arjun Kumar", "Priya Singh", "Rohit Sharma", "Sneha Patel", "Vikram Mehta"]
    for i, name in enumerate(names):
        db.add(RiderRecord(
            name   = name,
            phone  = f"98{i:08d}",
            x      = round(random.uniform(1, 9), 1),
            y      = round(random.uniform(1, 9), 1),
            rating = round(random.uniform(3.5, 5.0), 1),
        ))
    db.commit()
    return {"msg": f"Seeded {len(names)} riders"}


@router.post("/riders/{rider_id}/free")
def free_rider(rider_id: str, db: Session = Depends(get_db)):
    """Reset a rider to idle (for demo resets)."""
    rider = db.query(RiderRecord).filter(RiderRecord.id == rider_id).first()
    if not rider:
        raise HTTPException(status_code=404, detail="Rider not found")
    rider.status = "idle"
    db.commit()
    return {"ok": True}


@router.post("/reset")
def reset_riders(db: Session = Depends(get_db)):
    """Free all riders (demo reset)."""
    db.query(RiderRecord).update({"status": "idle"})
    db.commit()
    return {"ok": True, "msg": "All riders set to idle"}
