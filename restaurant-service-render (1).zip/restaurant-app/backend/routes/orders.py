"""
routes/orders.py
Order management — idempotency, queue, DLQ, retry.
Replaces the MongoDB-based restaurant service with SQLite.
"""

import json
import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from database.db import get_db
from database.models import Order, DeadLetterEntry
from services.queue import enqueue_order

router = APIRouter()

# In-memory idempotency cache (seeded from DB on startup)
_idempotency_cache: set = set()


def rebuild_cache(db: Session):
    """Re-populate the in-memory cache from DB (called at startup)."""
    keys = db.query(Order.idempotency_key).all()
    for (k,) in keys:
        if k:
            _idempotency_cache.add(k)


# ── Schemas ────────────────────────────────────────────────────────────────────

class PlaceOrderRequest(BaseModel):
    idempotency_key: str
    customer_name:   str
    customer_email:  str = ""
    restaurant:      str
    items:           list[str]
    amount:          float


# ── Endpoints ──────────────────────────────────────────────────────────────────

@router.post("/place")
def place_order(payload: PlaceOrderRequest, db: Session = Depends(get_db)):
    """
    Place a restaurant order.
    - Idempotency: duplicate keys return 409
    - Enqueues to in-memory SQS-like queue for async processing
    """
    if payload.idempotency_key in _idempotency_cache:
        raise HTTPException(status_code=409, detail="Duplicate request — idempotency key already used")

    # Save order to DB
    order = Order(
        idempotency_key = payload.idempotency_key,
        customer_name   = payload.customer_name,
        customer_email  = payload.customer_email,
        restaurant      = payload.restaurant,
        items           = json.dumps(payload.items),
        amount          = payload.amount,
        status          = "PLACED",
    )
    db.add(order)
    db.commit()
    db.refresh(order)

    # Add to cache
    _idempotency_cache.add(payload.idempotency_key)

    # Enqueue for async processing
    enqueue_order({
        "order_id":    order.order_id,
        "amount":      order.amount,
        "restaurant":  order.restaurant,
        "items":       payload.items,
    })

    return {
        "status":   "Order Accepted",
        "order_id": order.order_id,
    }


@router.get("/")
def list_orders(limit: int = 20, db: Session = Depends(get_db)):
    orders = db.query(Order).order_by(Order.created_at.desc()).limit(limit).all()
    return [_order_dict(o) for o in orders]


@router.get("/dlq")
def view_dlq(db: Session = Depends(get_db)):
    """View dead-letter queue entries (failed orders that exhausted retries)."""
    entries = db.query(DeadLetterEntry).order_by(DeadLetterEntry.created_at.desc()).all()
    return {
        "failed_messages": [
            {
                "id":        e.id,
                "order_id":  e.order_id,
                "reason":    e.reason,
                "payload":   json.loads(e.payload) if e.payload else {},
                "created_at": e.created_at.isoformat() if e.created_at else None,
            }
            for e in entries
        ]
    }


@router.get("/{order_id}")
def get_order(order_id: str, db: Session = Depends(get_db)):
    order = db.query(Order).filter(Order.order_id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    return _order_dict(order)


# ── Helper ─────────────────────────────────────────────────────────────────────

def _order_dict(o: Order) -> dict:
    return {
        "order_id":       o.order_id,
        "customer_name":  o.customer_name,
        "customer_email": o.customer_email,
        "restaurant":     o.restaurant,
        "items":          json.loads(o.items) if o.items else [],
        "amount":         o.amount,
        "status":         o.status,
        "retry_count":    o.retry_count,
        "created_at":     o.created_at.isoformat() if o.created_at else None,
    }
