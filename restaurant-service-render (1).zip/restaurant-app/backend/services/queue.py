"""
services/queue.py
Lightweight in-memory SQS simulator.
In production swap the Queue for boto3 SQS / Kafka / RabbitMQ.
"""

from queue import Queue

_order_queue: Queue = Queue()


def enqueue_order(order: dict) -> None:
    """Put an order onto the queue (producer side)."""
    _order_queue.put(order)


def dequeue_order(timeout: float = 1.0):
    """
    Block until an order is available or timeout expires.
    Returns the order dict or None on timeout.
    """
    try:
        return _order_queue.get(timeout=timeout)
    except Exception:
        return None
