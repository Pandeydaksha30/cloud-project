"""
services/order_processor.py
Background worker thread — processes queued orders, handles retries & DLQ.
Mirrors the worker.py + retry_manager.py + dlq.py logic from the original project.
"""

import json
import logging
import time
from datetime import datetime

from database.db import SessionLocal
from database.models import Order, DeadLetterEntry
from services.queue import dequeue_order

logger     = logging.getLogger("order_worker")
MAX_RETRY  = 3


def _process(order: dict) -> None:
    """
    Simulate order processing (restaurant → kitchen → notification).
    Raises an exception for invalid orders so retry logic can kick in.
    """
    if order.get("amount", 0) < 0:
        raise ValueError(f"Invalid amount {order['amount']} in order {order.get('order_id')}")

    # Simulate kitchen processing
    logger.info(f"[WORKER] Processing order {order.get('order_id')} "
                f"— {order.get('restaurant')}, ₹{order.get('amount')}")
    time.sleep(0.1)   # Simulate work


def _update_status(order_id: str, status: str, retry_count: int = None) -> None:
    db = SessionLocal()
    try:
        record = db.query(Order).filter(Order.order_id == order_id).first()
        if record:
            record.status     = status
            record.updated_at = datetime.utcnow()
            if retry_count is not None:
                record.retry_count = retry_count
            db.commit()
    finally:
        db.close()


def _send_to_dlq(order: dict, reason: str) -> None:
    db = SessionLocal()
    try:
        entry = DeadLetterEntry(
            order_id = order.get("order_id", "unknown"),
            payload  = json.dumps(order),
            reason   = reason,
        )
        db.add(entry)
        db.commit()
        logger.warning(f"[DLQ] Order {order.get('order_id')} sent to DLQ: {reason}")
    finally:
        db.close()


def start_order_worker() -> None:
    """
    Blocking loop — run in a daemon thread.
    Continuously pulls orders from the queue and processes them.
    """
    logger.info("[WORKER] Order processor started")
    retry_counts: dict = {}   # order_id → retry count

    while True:
        order = dequeue_order(timeout=1.0)
        if order is None:
            continue

        oid = order.get("order_id", "unknown")
        retries = retry_counts.get(oid, 0)

        try:
            _process(order)
            _update_status(oid, "DELIVERED")
            retry_counts.pop(oid, None)
            logger.info(f"[WORKER] ✅ Order {oid} delivered")

        except Exception as exc:
            logger.warning(f"[WORKER] ⚠ Order {oid} failed (attempt {retries + 1}): {exc}")

            if retries < MAX_RETRY:
                retry_counts[oid] = retries + 1
                _update_status(oid, "RETRYING", retry_count=retries + 1)
                # Re-enqueue with a short delay
                time.sleep(0.5)
                from services.queue import enqueue_order
                enqueue_order(order)
            else:
                _update_status(oid, "FAILED")
                _send_to_dlq(order, str(exc))
                retry_counts.pop(oid, None)
